# RUIFLOW 2D Fast Preview · Harness Optional Demo Plugin Spec

时间：2026-06-12 20:54 GMT+8
状态：Spec only，不进入 Harness 核心包

## 1. 定位

RUIFLOW 2D fast-preview 是 Harness 的 optional demo plugin，用来展示 Harness 可以调度本地 AI/内容生成任务。

不是 Harness 核心能力。  
不是商业包默认内置功能。  
不是对外承诺的通用视频生成能力。

## 2. 插件边界

允许：

- 本地 runner demo
- 本地输入 prompt
- 本地输出 preview artifact
- 标记为 fast_preview_not_hq

禁止：

- 携带内部 FOS/CEO 上下文
- 携带 credentials
- 自动上传素材
- 对外承诺高质量生产级视频
- 依赖付费 API 默认运行

## 3. Runner 名称

```text
ruiflow_2d_fast_preview
```

## 4. 输入

```json
{
  "prompt": "short creative prompt",
  "style": "optional style",
  "seconds": 2,
  "quality_scope": "fast_preview_not_hq"
}
```

## 5. 输出

```json
{
  "status": "success|failed",
  "artifact": "local path or url",
  "elapsed_seconds": 0,
  "cost": "local_mac_mps_yuan_0",
  "quality_scope": "fast_preview_not_hq"
}
```

## 6. 商业口径

正确说法：

> Harness 可以调度本地内容生成插件；RUIFLOW 2D 是一个内部 demo plugin，用来验证工作流执行能力。

禁止说法：

> Harness 已内置专业 AI 视频生成。

## 7. 接入时机

v0.6 后再接。  
当前 v0.5 只保留 spec。
