# Harness Local v0.11 Install / Run Guide

时间：2026-06-12 21:09 GMT+8

## 前置条件

```bash
python3 --version
```

建议：Python 3.9+。

Harness Local v0.11 不需要数据库、不需要云服务、不需要 API key 才能运行基础功能。

## 启动

```bash
cd harness-commercial
./harness serve
```

打开：

```text
http://127.0.0.1:8788
```

## 使用隔离数据目录

```bash
HARNESS_DATA_DIR=/tmp/harness-local-data ./harness serve
```

## 空数据 smoke

```bash
./harness smoke-empty
```

期望：

```json
{
  "status": "PASS",
  "version": "0.11",
  "empty_workspaces": 0,
  "empty_tasks": 0,
  "release_readiness_status": "PASS"
}
```

## 常见问题

### 8788 被占用

先停止旧 server，或使用：

```bash
HARNESS_PORT=8789 ./harness serve
```

### 看不到 workspace

确认路径存在，并且有读取权限。

### 安全边界

- 不默认上传项目文件
- 不默认读取凭证
- 不执行破坏性命令
- optional plugins 默认 disabled


## v0.11 新增

- Dashboard 可构建 beta zip。
- `/package-qa` 可校验最新 zip 的 sha256、路径边界、单根目录、必需文件与内嵌 manifest。
- 分享 beta 包前必须 Package QA PASS。
