# Harness Local API Contract v0.7

时间：2026-06-12 21:03 GMT+8

## 安全总则

- API 默认服务于 localhost dashboard。
- 默认不上传文件。
- 默认不读取 credentials。
- 默认不执行 destructive command。
- git diff 只输出 stat/name-only。

## GET /health

响应：

```json
{"status":"ok","product":"Harness Local","version":"0.7","ts":"..."}
```

## GET /api/workspaces

返回 active workspaces。默认隐藏 archived。

## POST /api/workspaces

请求：

```json
{"path":"/local/project/path"}
```

行为：

- normalize path
- same path dedupe
- scan top-level context

## GET /api/workspaces/:id/context

返回 workspace scan：entries、README excerpt、git flag。

## GET /api/workspaces/:id/boundary

返回 package boundary scan：PASS/FAIL + forbidden hits。

## POST /api/workspaces/:id/archive

归档 workspace record，不删除文件。

## POST /api/workspaces/cleanup

归档历史重复 workspace record，不删除文件。

## GET /api/tasks

返回任务列表。

## POST /api/tasks

请求：

```json
{"workspace_id":"ws_xxx","goal":"..."}
```

返回 template planner steps。

## POST /api/tasks/:id/run

运行 read-only git status。

## POST /api/tasks/:id/diff

运行 read-only git diff summary：

```text
git diff --stat
git diff --name-only
```

不输出全文 diff。

## POST /api/tasks/:id/audit

一键 safe audit：context scan + git status + git diff summary + boundary scan + markdown report。

## POST /api/tasks/:id/plan

重新生成 template planner steps。

## GET /api/reports

列出 Markdown reports。

## POST /api/reports

生成普通 Markdown report。

## GET /reports/report_*.md

只允许读取 report markdown 文件。

## GET /api/audit/summary

返回 latest safe audit status、last run、last report。

## GET /api/plugins

返回 plugin registry。v0.7 只展示 registry，不执行插件。

## GET /api/release/readiness

发布前 readiness 检查：package boundary、README、plugins disabled、docs。
