# Harness Local 3-minute Demo Script

目标：非技术用户在本机 3 分钟内确认内部 beta 包可运行。

## 从源码目录运行

```bash
./harness first-run

# Optional reset-only path
./harness clean-demo
./harness demo
./harness doctor
./harness export-evidence
./harness open
```

## 从解压包运行

```bash
unzip harness-local-v0.24-beta.zip
cd harness-local-v0.24-beta
./harness smoke-empty
./harness first-run

# Optional reset-only path
./harness clean-demo
./harness demo
./harness doctor ../harness-local-v0.24-beta.zip
./harness package-verify ../harness-local-v0.24-beta.zip
./harness export-evidence
./harness open
```

## 成功标准

- Demo status = PASS
- Doctor status = PASS
- Release Center 打开并显示 Package QA PASS / Demo PASS / RC LOCKED

## 安全边界

- 不上传项目文件
- 不读取凭证
- 不执行破坏性命令
- 默认只绑定 127.0.0.1
