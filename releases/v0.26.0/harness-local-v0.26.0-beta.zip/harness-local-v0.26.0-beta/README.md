# Harness Local

Harness Local 是一个本地优先的 AI Agent 执行工作台。

一句话：**在你的电脑上，把 AI 从聊天变成可执行的任务流。**

## 当前定位

Harness Local 面向开发者、独立创作者和 AI power user，帮助你在本机完成：

- 添加本地项目 workspace
- 把目标拆成可执行 task steps
- 运行只读检查，例如 git status / git diff summary
- 生成本地 Markdown 报告
- 做发布前边界检查
- 管理 optional demo plugins

## 安全默认值

Harness Local 默认保持安全边界：

- 本地优先，默认 `127.0.0.1`
- 不默认上传项目文件
- 不执行 destructive command
- 不读取凭证文件
- 不保存明文 API key
- git diff 默认只输出摘要，不输出全文 diff
- workspace archive 不删除磁盘文件
- optional plugins 默认 disabled

## 快速开始

```bash
cd harness-commercial
./harness serve
open http://127.0.0.1:8788
```

## 3 分钟演示

1. Add workspace：选择一个本地项目路径。
2. Create task：输入目标，例如“执行一键 safe audit 并生成本地报告”。
3. Safe audit：生成本地安全审计报告。
4. View inline：在页面内查看 Markdown 报告。
5. Build beta zip：生成本地 beta 包。
6. Package QA：校验 zip 路径、安全边界、sha256、内嵌 manifest。
7. Plugin registry：查看 optional demo plugins。

## 当前版本能力

- Local Web dashboard
- Workspace context scan
- Template planner v0
- Read-only git status
- Read-only git diff summary
- One-click safe audit
- Markdown report export and inline viewer
- Workspace dedupe / archive / cleanup
- Release readiness check
- Beta zip build and Package QA verification
- Plugin registry v0
- Tauri desktop shell skeleton

## 非目标

当前版本不会承诺：

- 100% 自动完成所有工作
- 替代完整团队
- 默认联网处理你的项目
- 默认执行会修改文件的命令
- 默认启用视频/图像生成插件

## 数据位置

默认数据目录：

```text
./data
```

开发和测试可通过环境变量隔离：

```bash
HARNESS_DATA_DIR=/tmp/harness-local-data ./harness serve
```

## Beta 反馈重点

欢迎重点反馈：

- 哪些本地检查最有价值
- safe audit 报告是否清楚
- task steps 是否符合你的工作习惯
- 你希望接入哪些 optional plugins


## Beta Release Guide

内部 beta 包安装与 QA 指南：`docs/HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md`。

分享前最低门槛：`./harness smoke-empty` PASS、Release readiness PASS、Package QA PASS、解压后独立运行 PASS。


## v0.13 Release Center

- `/release` 现在是一页式 Release Center：Package、QA、Install Guide、Download、Checklist 四件套。
- 新增 `./harness package-verify`：不打开浏览器也能校验最新 beta zip。


## v0.14 Release Candidate Lock

- `./harness package-build`：不打开浏览器也能构建 beta zip。
- `./harness candidate` / `./harness candidate-lock`：查看或锁定 Release Candidate。
- Release Center 支持复制 CLI、SHA 和安装命令。


### RC lock artifact policy

`RELEASE-CANDIDATE.json` 不打入 zip；它是 zip 外部锁定文件，记录当前 beta zip 的 sha256、QA 和 readiness，避免自引用改变 zip sha。网页端：`/release-candidate.json`。


## v0.24 Doctor / Open

- `./harness doctor [zip_path]`：一次检查 Python、端口、zip、RC、QA、readiness；解压包可指定外部 zip。
- `./harness open`：启动本地 server 并打开浏览器。
- Release Center 显示 Doctor PASS/WARN/FAIL，降低首次运行摩擦。


## v0.24 3-minute Demo

- `./harness demo`：生成本地 demo workspace、sample task、只读 evidence runs、safe audit report。
- `./harness doctor [zip_path]`：包含 3-minute demo 状态检查。
- `./harness open`：打开 Release Center。
- 推荐试用：`./harness demo && ./harness doctor && ./harness open`。


## v0.24 Repeatable Demo Reset

- `./harness clean-demo`：清理 Harness 生成的 demo workspace / demo task / demo runs / demo report。
- Release Center 提供 Reset Demo。
- Demo 区块提供最新 demo report 链接。
- 推荐重复演示：`./harness clean-demo && ./harness demo && ./harness doctor && ./harness open`。


## v0.24 Evidence Pack

- `./harness export-evidence`：导出本地证据包目录到 `dist/evidence/`，不上传。
- Release Center 提供 Export Evidence Pack。
- 证据包包含 manifest、QA、RC、doctor、demo summary、demo report、SHA256SUMS。


## v0.24 First Run Wizard

- `./harness first-run`：一键完成本地内部 beta 体验准备。
- 执行链路：clean-demo → demo → package-build → package-verify → candidate-lock → doctor → export-evidence。
- Release Center 提供 First Run Wizard 按钮。


## v0.24 Trial Note

- `./harness trial-note`：生成内部试用说明书 `dist/evidence/TRIAL-NOTE.md`。
- 内容包括安装步骤、安全边界、SHA256、验收 PASS 摘要、常见问题。
- `/first-run` 页面提供 Copy/Download Trial Note。


## v0.24 Print Checklist

- `./harness print-checklist`：生成可打印内部核验单 `dist/evidence/CHECKLIST.html`。
- 内容包括包名、SHA256、Package QA、RC Lock、Doctor、Demo、Evidence、Trial Note 状态。
- `/first-run` 页面提供 Print Checklist。


## v0.24 Feedback Capture

- `/feedback`：本地内部试用反馈页。
- `data/feedback.jsonl`：反馈仅保存本机。
- `./harness feedback-export`：导出 `dist/evidence/FEEDBACK-SUMMARY.md`。
- 不上传、不外发、不读凭证。


## v0.24 Trial Bundle

- `./harness trial-bundle`：生成 `dist/evidence/TRIAL-BUNDLE/` 本地内部试用证据包。
- 聚合 Trial Note、Checklist、Feedback Summary、Evidence README、Demo Report、关键 JSON 与 SHA256SUMS。
- 不上传、不外发、不读取凭证、不压进 beta zip。


## v0.24.3 中文内页修复

- 发布中心、安装包 QA、反馈页进一步中文化。
- 真实产品演示素材使用本地中文面板录制。
- 仍保持本地优先：默认 127.0.0.1，不默认上传项目，不读取凭证文件。


## 脱敏反馈包

如果安装或自检遇到问题，可以先在本机生成脱敏反馈包：

```bash
./harness feedback-bundle
```

输出目录：`dist/evidence/TRIAL-BUNDLE/`。

安全边界：不上传、不读取凭证、不复制原始 `data/feedback.jsonl`，只包含 doctor、smoke/demo 摘要、反馈摘要和本地证据索引。提交公开 issue 前请先人工检查 README.md / FEEDBACK-SUMMARY.md / doctor.json。


## v0.25 Doctor Diagnosis Report

- `./harness doctor` now includes a `diagnosis` object with three buckets: `must_fix`, `should_fix`, and `can_ignore`.
- `./harness doctor-report` prints a Markdown checkup report for local review before sharing feedback.
- `./harness feedback-bundle` includes `DOCTOR-REPORT.md` plus JSON evidence, while still excluding source code, secrets, raw feedback JSONL, and customer data.
- This is a local-only diagnostic format for AI project checkups; manually review all files before attaching anything to a public issue.


## Checkup sample schema

Generate a deidentified local AI project checkup sample:

```bash
./harness checkup-sample
```

The command writes:

```text
dist/evidence/CHECKUP-SAMPLE/checkup-sample.json
dist/evidence/CHECKUP-SAMPLE/CHECKUP-SAMPLE.md
```

Read `docs/CHECKUP-SAMPLE-SCHEMA.md` for field meanings and safe interpretation rules. The sample is not a customer case, not external validation, not paid traction, and not production-readiness proof.
