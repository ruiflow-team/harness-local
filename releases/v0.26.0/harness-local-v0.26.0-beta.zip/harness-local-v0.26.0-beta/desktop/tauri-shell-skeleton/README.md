# Harness Desktop Tauri Shell Skeleton

状态：skeleton only；未安装依赖，未联网，未花钱。

## 目标

最小桌面壳：

```text
Harness.app -> starts local Harness server -> opens local dashboard
```

## 目录

```text
src-tauri/       # future Tauri Rust shell
ui/              # WebView landing placeholder
```

## 计划

1. Tauri 启动时找可用端口。
2. 以 child process 启动 `harness serve`。
3. health check `/health`。
4. WebView 打开 `http://127.0.0.1:<port>`。
5. App 退出时停止 server。

## 安全边界

- bind 127.0.0.1
- no cloud upload by default
- no destructive command
- folder chosen by user
- keychain later, no plaintext key in v0
