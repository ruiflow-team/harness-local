# Harness Desktop Service Lifecycle Checklist

状态：v0.7 checklist；不安装依赖、不打包。

## Start

- 查找可用 localhost port，优先 8788。
- 启动 Harness Local server。
- 环境变量：`HARNESS_HOST=127.0.0.1`、`HARNESS_PORT=<port>`。

## Poll

- 轮询 `/health`。
- 成功条件：`status=ok` 且 version 符合桌面壳期望。
- 超时后显示本地错误，不静默失败。

## Open

- WebView 打开 `http://127.0.0.1:<port>`。
- 不加载远程 UI。

## Stop

- App 退出时 kill child process。
- 如果 server 已退出，不重复报错。

## Crash Recover

- child process 异常退出时显示“Restart local service”。
- 不自动重启死循环。

## Logs

- 本地日志写入 app data 目录。
- 日志不得包含 API key、credentials、private file content。

## Release Gate

打包前必须通过：

```text
GET /api/release/readiness
```

目标：`status=PASS`。
