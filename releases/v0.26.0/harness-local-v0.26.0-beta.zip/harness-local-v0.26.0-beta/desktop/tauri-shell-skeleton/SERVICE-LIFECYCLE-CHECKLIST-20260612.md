# Harness Tauri Service Lifecycle Checklist

Date: 2026-06-12
Scope: beta desktop wrapper around Harness Local Web.

## Goal

Tauri shell owns a local Harness service process safely and visibly.

## Startup

- [ ] Choose free localhost port, default preference `8788`.
- [ ] Start service with explicit env:
  - `HARNESS_HOST=127.0.0.1`
  - `HARNESS_PORT=<selected_port>`
  - optional `HARNESS_DATA_DIR=<app-data-dir>`
- [ ] Wait for `GET /health`.
- [ ] Verify `product=Harness Local` and expected version.
- [ ] Open shell window to `http://127.0.0.1:<port>/`.

## Runtime Monitoring

- [ ] Keep service pid in app state.
- [ ] Show status badge: starting / healthy / stopped / error.
- [ ] Poll `/health` lightly, not more than every 5 seconds.
- [ ] Surface logs in local diagnostics panel.
- [ ] Never expose service on `0.0.0.0` in beta.

## Shutdown

- [ ] On normal app quit, terminate child process.
- [ ] Wait briefly for graceful exit.
- [ ] Kill only the owned pid if still running.
- [ ] Never kill arbitrary processes by port.

## Upgrade

- [ ] Stop owned service before replacing binary/scripts.
- [ ] Preserve app data directory.
- [ ] Run `harness smoke-empty` against temporary data before marking upgrade healthy.
- [ ] If health fails, show rollback/retry state; do not delete user data.

## Failure Modes

- Port busy: select another local port and show it.
- Health timeout: show logs and retry button.
- Data dir unreadable: show permission guidance.
- Boundary check FAIL: block packaging/release, not normal local usage.

## Beta Non-Goals

- No background auto-start daemon.
- No LAN exposure.
- No cloud sync.
- No credential storage.
