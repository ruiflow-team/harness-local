# Harness Desktop Launch Script Draft

状态：draft only；不安装依赖、不执行打包。

## 目标流程

```text
1. find free localhost port
2. start ./harness serve on 127.0.0.1:<port>
3. poll /health
4. open Tauri WebView to local dashboard
5. on app exit, terminate child process
```

## 伪代码

```rust
let port = find_free_port(8788..8899);
let child = Command::new("./harness")
  .arg("serve")
  .env("HARNESS_HOST", "127.0.0.1")
  .env("HARNESS_PORT", port.to_string())
  .spawn()?;
wait_health(format!("http://127.0.0.1:{}/health", port));
open_webview(format!("http://127.0.0.1:{}", port));
on_exit(|| child.kill());
```

## 安全边界

- 只绑定 127.0.0.1
- 不自动扫描全盘
- folder 必须用户选择
- 退出清理 server
- build 前跑 boundary scan
