#!/usr/bin/env python3
"""Harness Local Web MVP server.

Local-first prototype. Default bind: 127.0.0.1:8788.
No cloud upload. No destructive command runner in v0.x.
"""
from __future__ import annotations

import json
import hashlib
import os
import shutil
import subprocess
import tempfile
import time
import uuid
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get("HARNESS_DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
STATIC = ROOT / "app" / "static"
WORKSPACES = DATA / "workspaces.json"
TASKS = DATA / "tasks.jsonl"
RUNS = DATA / "runs.jsonl"
AUDIT = DATA / "audit.jsonl"
REPORTS = DATA / "reports"
SETTINGS = DATA / "settings.json"
PLUGINS = ROOT / "plugins" / "registry.json"
PACKAGE_MANIFEST = ROOT / "RELEASE-MANIFEST.json"
DIST = ROOT / "dist"
PACKAGES = DIST / "packages"
PACKAGE_INDEX = PACKAGES / "package-index.json"
PACKAGE_QA = PACKAGES / "package-qa-latest.json"
PACKAGE_CANDIDATE = PACKAGES / "RELEASE-CANDIDATE.json"
EVIDENCE = DIST / "evidence"
EVIDENCE_INDEX = EVIDENCE / "evidence-index.json"
FEEDBACK = DATA / "feedback.jsonl"
VERSION = "0.24.4"

DATA.mkdir(parents=True, exist_ok=True)
STATIC.mkdir(parents=True, exist_ok=True)
REPORTS.mkdir(parents=True, exist_ok=True)
PACKAGES.mkdir(parents=True, exist_ok=True)
EVIDENCE.mkdir(parents=True, exist_ok=True)

SAFE_SETTINGS_KEYS = {"model_provider", "local_endpoint", "key_mode"}
DEFAULT_SETTINGS = {
    "model_provider": "local_or_user_selected",
    "local_endpoint": "",
    "key_mode": "user_provided_not_stored_in_v0",
}


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def normalize_path(path: str) -> str:
    return str(Path(path).expanduser().resolve())


def read_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def append_jsonl(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def read_jsonl(path: Path):
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    return rows


def rewrite_jsonl(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    tmp.replace(path)


def audit(action: str, payload: dict) -> None:
    append_jsonl(AUDIT, {"ts": now(), "action": action, "payload": payload})


def scan_workspace(path: str) -> dict:
    p = Path(path).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise ValueError("workspace path does not exist or is not a directory")
    # v0: bounded, non-recursive-ish safe scan
    entries = []
    for child in sorted(p.iterdir(), key=lambda x: x.name.lower())[:80]:
        name = child.name
        if name in {".git", "node_modules", ".venv", "venv", "__pycache__"}:
            entries.append({"name": name, "type": "dir", "skipped": True})
            continue
        entries.append({"name": name, "type": "dir" if child.is_dir() else "file"})
    readme = ""
    for candidate in ["README.md", "readme.md", "README.txt"]:
        rp = p / candidate
        if rp.exists() and rp.is_file():
            readme = rp.read_text(encoding="utf-8", errors="ignore")[:3000]
            break
    git_exists = (p / ".git").exists()
    return {"path": str(p), "entries": entries, "readme_excerpt": readme, "git": git_exists, "scanned_at": now()}


def get_workspace(workspace_id: str) -> dict | None:
    for ws in read_json(WORKSPACES, []):
        if ws.get("id") == workspace_id:
            return ws
    return None


def update_workspace(workspace_id: str, **updates) -> dict:
    rows = read_json(WORKSPACES, [])
    updated = None
    for row in rows:
        if row.get("id") == workspace_id:
            row.update(updates)
            row["updated_at"] = now()
            updated = row
            break
    if updated is None:
        raise ValueError("workspace not found")
    write_json(WORKSPACES, rows)
    return updated


def archive_workspace(workspace_id: str) -> dict:
    return update_workspace(workspace_id, archived=True, archived_at=now())


def get_task(task_id: str) -> dict | None:
    for task in read_jsonl(TASKS):
        if task.get("id") == task_id:
            return task
    return None


def update_task(task_id: str, **updates) -> dict:
    rows = read_jsonl(TASKS)
    updated = None
    for row in rows:
        if row.get("id") == task_id:
            row.update(updates)
            row["updated_at"] = now()
            updated = row
            break
    if updated is None:
        raise ValueError("task not found")
    rewrite_jsonl(TASKS, rows)
    return updated


def run_git_status(workspace_path: str) -> dict:
    p = Path(workspace_path).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise ValueError("workspace path does not exist or is not a directory")
    if not (p / ".git").exists():
        return {
            "status": "DONE",
            "stdout": "Workspace is not a git repository. Nothing to report from git status.",
            "stderr": "",
            "returncode": 0,
        }
    cp = subprocess.run(
        ["git", "status", "--short", "--branch"],
        cwd=str(p),
        text=True,
        capture_output=True,
        timeout=10,
        check=False,
    )
    return {
        "status": "DONE" if cp.returncode == 0 else "FAILED",
        "stdout": cp.stdout.strip(),
        "stderr": cp.stderr.strip(),
        "returncode": cp.returncode,
    }


def run_git_diff_summary(workspace_path: str) -> dict:
    p = Path(workspace_path).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise ValueError("workspace path does not exist or is not a directory")
    if not (p / ".git").exists():
        return {"status": "DONE", "stdout": "Workspace is not a git repository. Nothing to report from git diff.", "stderr": "", "returncode": 0}
    stat = subprocess.run(["git", "diff", "--stat"], cwd=str(p), text=True, capture_output=True, timeout=10, check=False)
    names = subprocess.run(["git", "diff", "--name-only"], cwd=str(p), text=True, capture_output=True, timeout=10, check=False)
    stdout = "## git diff --stat\n" + (stat.stdout.strip() or "No unstaged diff.") + "\n\n## git diff --name-only\n" + (names.stdout.strip() or "No changed files.")
    stderr = "\n".join(x for x in [stat.stderr.strip(), names.stderr.strip()] if x)
    code = stat.returncode or names.returncode
    return {"status": "DONE" if code == 0 else "FAILED", "stdout": stdout, "stderr": stderr, "returncode": code}


def scan_package_boundary(workspace_path: str) -> dict:
    p = Path(workspace_path).expanduser().resolve()
    deny_names = {"MEMORY.md", "CREDENTIALS.md", "CREDENTIALS-SECRETS.md", "openclaw.json"}
    deny_fragments = ["CREDENTIALS", "CEO-MEMORY", "ceo-memory", "workspace-main", ".openclaw/openclaw.json"]
    hits = []
    for root, dirs, files in os.walk(p):
        rel_root = os.path.relpath(root, p)
        if any(part in {".git", "node_modules", ".venv", "venv", "__pycache__", "data"} for part in Path(rel_root).parts):
            dirs[:] = []
            continue
        for name in files:
            rel = str(Path(rel_root) / name) if rel_root != "." else name
            if name in deny_names or any(frag in rel for frag in deny_fragments):
                hits.append(rel)
    status = "PASS" if not hits else "FAIL"
    return {"status": status, "hits": hits[:100], "checked_at": now(), "rules": sorted(list(deny_names)) + deny_fragments}


def get_settings() -> dict:
    data = DEFAULT_SETTINGS | read_json(SETTINGS, {})
    # Never echo accidental secret-looking fields if someone wrote them manually.
    return {k: data.get(k, DEFAULT_SETTINGS.get(k, "")) for k in SAFE_SETTINGS_KEYS}


def save_settings(raw: dict) -> dict:
    clean = DEFAULT_SETTINGS.copy()
    for key in SAFE_SETTINGS_KEYS:
        if key in raw:
            clean[key] = str(raw.get(key) or "")[:500]
    clean["key_mode"] = "user_provided_not_stored_in_v0"
    write_json(SETTINGS, clean)
    audit("settings.updated", {"keys": sorted(clean.keys()), "key_mode": clean["key_mode"]})
    return clean


def plan_steps(goal: str, workspace: dict | None = None) -> list[dict]:
    text = (goal or "").lower()
    steps = [
        {"id": "step_context", "title": "Scan project context", "runner": "context_scan", "safety": "read_only"},
        {"id": "step_git", "title": "Check git status", "runner": "git_status", "safety": "read_only"},
        {"id": "step_diff", "title": "Summarize git diff safely", "runner": "git_diff_summary", "safety": "read_only_no_full_diff"},
    ]
    if any(k in text for k in ["readme", "文档", "doc", "landing", "homepage", "文案"]):
        steps.append({"id": "step_doc_review", "title": "Review docs/copy gaps", "runner": "planner_note", "safety": "no_write"})
    elif any(k in text for k in ["test", "bug", "fix", "失败", "报错"]):
        steps.append({"id": "step_test_plan", "title": "Prepare safe test/debug checklist", "runner": "planner_note", "safety": "needs_confirmation_before_shell"})
    else:
        steps.append({"id": "step_plan", "title": "Break goal into execution checklist", "runner": "planner_note", "safety": "no_write"})
    steps.append({"id": "step_boundary", "title": "Scan packaging boundary", "runner": "package_boundary_scan", "safety": "local_only_no_secret_read"})
    steps.append({"id": "step_report", "title": "Generate evidence report", "runner": "markdown_report", "safety": "local_only"})
    if workspace and workspace.get("scan", {}).get("readme_excerpt"):
        steps[0]["evidence"] = "README detected"
    return steps


def list_reports() -> list[dict]:
    rows = []
    for path in sorted(REPORTS.glob("report_*.md"), key=lambda p: p.stat().st_mtime, reverse=True):
        rows.append({"id": path.stem, "path": str(path), "name": path.name, "mtime": int(path.stat().st_mtime), "url": f"/reports/{path.name}"})
    return rows[:100]


def make_markdown_report() -> dict:
    workspaces = read_json(WORKSPACES, [])
    tasks = read_jsonl(TASKS)
    runs = read_jsonl(RUNS)
    report_id = "report_" + uuid.uuid4().hex[:10]
    path = REPORTS / f"{report_id}.md"
    lines = [
        f"# Harness Local Report {report_id}",
        "",
        f"- Generated: {now()}",
        f"- Product: Harness Local v{VERSION}",
        f"- Workspaces: {len(workspaces)}",
        f"- Tasks: {len(tasks)}",
        f"- Runs: {len(runs)}",
        "",
        "## Boundary",
        "",
        "Local-first report. v0.11 includes release boundary check, empty-data smoke support, duplicate workspace cleanup, audit summary card, plugin registry, one-click safe audit, embedded markdown reports, beta zip build, and package QA verification; no cloud upload, no credential capture, no destructive commands.",
        "",
        "## Workspaces",
        "",
    ]
    if workspaces:
        for ws in workspaces[-20:]:
            lines += [
                f"### {ws.get('name', ws.get('id'))}",
                f"- ID: `{ws.get('id')}`",
                f"- Path: `{ws.get('path')}`",
                f"- Git: `{bool(ws.get('scan', {}).get('git'))}`",
                "",
            ]
    else:
        lines += ["No workspaces recorded.", ""]

    lines += ["## Recent Tasks", ""]
    if tasks:
        for task in tasks[-30:]:
            lines += [
                f"- `{task.get('id')}` **{task.get('status')}** — {task.get('goal', '')}",
                f"  - workspace: `{task.get('workspace_id')}`; last_run: `{task.get('last_run_id', '')}`",
            ]
        lines.append("")
    else:
        lines += ["No tasks recorded.", ""]

    lines += ["## Recent Runs", ""]
    if runs:
        for run in runs[-30:]:
            lines += [
                f"### {run.get('id')} — {run.get('status')}",
                f"- Task: `{run.get('task_id')}`",
                f"- Runner: `{run.get('runner')}`",
                f"- Created: `{run.get('created_at')}`",
                "",
                "**stdout**",
                "```text",
                str(run.get("stdout", ""))[:4000],
                "```",
                "",
            ]
            if run.get("stderr"):
                lines += ["**stderr**", "```text", str(run.get("stderr", ""))[:4000], "```", ""]
    else:
        lines += ["No runs recorded.", ""]

    path.write_text("\n".join(lines), encoding="utf-8")
    return {
        "id": report_id,
        "created_at": now(),
        "summary": f"Harness Local v{VERSION}: {len(tasks)} tasks, {len(runs)} runs, {len(workspaces)} workspaces recorded.",
        "path": str(path),
        "url": f"/reports/{path.name}",
    }


def make_safe_audit_report(workspace: dict, task: dict | None = None) -> dict:
    scan = scan_workspace(workspace["path"])
    git_status = run_git_status(workspace["path"])
    git_diff = run_git_diff_summary(workspace["path"])
    boundary = scan_package_boundary(workspace["path"])
    report_id = "report_" + uuid.uuid4().hex[:10]
    path = REPORTS / f"{report_id}.md"
    lines = [
        f"# Harness Safe Audit Report {report_id}",
        "",
        f"- Generated: {now()}",
        f"- Product: Harness Local v{VERSION}",
        f"- Workspace: `{workspace.get('name')}`",
        f"- Path: `{workspace.get('path')}`",
        f"- Task: `{task.get('id') if task else ''}`",
        "",
        "## Safety Boundary",
        "",
        "This audit is local-only and read-only. It does not upload data, does not read credentials, and does not emit full git diff content.",
        "",
        "## Context Scan",
        "",
        f"- Entries: {len(scan.get('entries', []))}",
        f"- Git repo: {bool(scan.get('git'))}",
        f"- Scanned at: {scan.get('scanned_at')}",
        "",
        "### README excerpt",
        "",
        "```text",
        (scan.get('readme_excerpt') or '')[:2000],
        "```",
        "",
        "## Git Status",
        "",
        "```text",
        str(git_status.get('stdout', ''))[:4000],
        "```",
        "",
        "## Git Diff Summary",
        "",
        "```text",
        str(git_diff.get('stdout', ''))[:4000],
        "```",
        "",
        "## Package Boundary",
        "",
        f"- Status: **{boundary.get('status')}**",
        f"- Hits: {len(boundary.get('hits', []))}",
        "",
    ]
    if boundary.get('hits'):
        lines += ["### Hits", ""] + [f"- `{h}`" for h in boundary.get('hits', [])]
    else:
        lines += ["No blocked internal/private files detected.", ""]
    lines += ["## Verdict", "", "PASS for local commercial-safe MVP packaging." if boundary.get('status') == 'PASS' else "BLOCKED: remove boundary hits before packaging.", ""]
    path.write_text("\n".join(lines), encoding="utf-8")
    return {"id": report_id, "created_at": now(), "summary": f"Safe audit {boundary.get('status')} for {workspace.get('name')}", "path": str(path), "url": f"/reports/{path.name}", "boundary": boundary}


def cleanup_duplicate_workspaces() -> dict:
    rows = read_json(WORKSPACES, [])
    seen = {}
    archived = []
    kept = []
    for row in rows:
        key = normalize_path(row.get("path", "")) if row.get("path") else row.get("id")
        if key not in seen:
            seen[key] = row
            kept.append(row)
            continue
        row["archived"] = True
        row["archived_at"] = now()
        row["archive_reason"] = f"duplicate_of:{seen[key].get('id')}"
        archived.append({"id": row.get("id"), "duplicate_of": seen[key].get("id"), "path": row.get("path")})
        kept.append(row)
    write_json(WORKSPACES, kept)
    return {"status": "DONE", "archived_count": len(archived), "archived": archived}


def latest_safe_audit_summary() -> dict:
    runs = read_jsonl(RUNS)
    reports = list_reports()
    safe_runs = [r for r in runs if r.get("runner") == "safe_audit"]
    last = safe_runs[-1] if safe_runs else None
    last_report = None
    if last and last.get("report_id"):
        for rep in reports:
            if rep.get("id") == last.get("report_id"):
                last_report = rep
                break
    status = "WARN"
    if last:
        status = "PASS" if last.get("status") == "DONE" else "FAIL"
    return {"status": status, "last_run": last, "last_report": last_report, "safe_audit_runs": len(safe_runs), "updated_at": now()}



def release_boundary_summary(workspace_path: str | None = None) -> dict:
    target = workspace_path or str(ROOT)
    boundary = scan_package_boundary(target)
    required = [
        {"name": "README.md", "path": str(ROOT / "README.md"), "status": "PASS" if (ROOT / "README.md").exists() else "FAIL"},
        {"name": "API contract", "path": str(ROOT / "docs" / "HARNESS-LOCAL-API-CONTRACT-V0.7-20260612.md"), "status": "PASS" if (ROOT / "docs" / "HARNESS-LOCAL-API-CONTRACT-V0.7-20260612.md").exists() else "FAIL"},
        {"name": "Tauri lifecycle checklist", "path": str(ROOT / "desktop" / "tauri-shell-skeleton" / "SERVICE-LIFECYCLE-CHECKLIST-20260612.md"), "status": "PASS" if (ROOT / "desktop" / "tauri-shell-skeleton" / "SERVICE-LIFECYCLE-CHECKLIST-20260612.md").exists() else "FAIL"},
        {"name": "Plugin registry", "path": str(PLUGINS), "status": "PASS" if PLUGINS.exists() else "WARN"},
    ]
    failed = [x for x in required if x["status"] == "FAIL"]
    status = "FAIL" if boundary.get("status") == "FAIL" or failed else "PASS"
    return {
        "status": status,
        "product": "Harness Local",
        "version": VERSION,
        "checked_at": now(),
        "target": str(Path(target).expanduser().resolve()),
        "boundary": boundary,
        "required_artifacts": required,
        "release_rule": "Package only if status=PASS; boundary hits or missing required beta artifacts block release.",
    }

def read_plugins() -> list[dict]:
    if not PLUGINS.exists():
        return []
    return json.loads(PLUGINS.read_text(encoding="utf-8"))


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def generate_package_manifest() -> dict:
    include_roots = ["README.md", "harness", "app", "desktop", "plugins"]
    safe_docs = {
        "docs/HARNESS-API-CONTRACT-V0.7-20260612.md",
        "docs/HARNESS-LOCAL-3MIN-DEMO-SCRIPT-20260612.md",
        "docs/HARNESS-LOCAL-INSTALL-RUN-GUIDE-V0.8-20260612.md",
        "docs/HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md",
        "docs/plugins/RUIFLOW-2D-FAST-PREVIEW-DEMO-PLUGIN-SPEC-20260612.md",
    }
    forbidden = ["CREDENTIALS", "MEMORY.md", "openclaw.json", "workspace-main", "CEO-MEMORY", "ceo-memory", "FOS"]
    files = []
    total_size = 0
    candidate_paths = []
    for rel_root in include_roots:
        root = ROOT / rel_root
        if not root.exists():
            continue
        candidate_paths.extend([root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()])
    candidate_paths.extend([(ROOT / d) for d in safe_docs if (ROOT / d).exists()])
    seen = set()
    for path in candidate_paths:
        rel = path.relative_to(ROOT).as_posix()
        if rel in seen:
            continue
        seen.add(rel)
        if any(token in rel for token in forbidden):
            continue
        if "/__pycache__/" in f"/{rel}" or rel.endswith('.pyc') or '.bak' in rel:
            continue
        size = path.stat().st_size
        total_size += size
        files.append({"path": rel, "size": size, "sha256": _sha256_file(path)})
    manifest = {
        "product": "Harness Local",
        "version": VERSION,
        "generated_at": now(),
        "root": ".",
        "file_count": len(files),
        "total_size": total_size,
        "files": sorted(files, key=lambda x: x["path"]),
        "safety_boundary": {
            "local_first": True,
            "default_bind": "127.0.0.1",
            "cloud_upload_default": False,
            "destructive_runner_default": False,
            "credential_read_default": False,
            "plaintext_key_storage_default": False,
            "plugins_default_disabled": True
        },
        "readiness": release_readiness(),
    }
    manifest_text = json.dumps(manifest, ensure_ascii=False, indent=2)
    manifest["manifest_sha256"] = hashlib.sha256(manifest_text.encode('utf-8')).hexdigest()
    write_json(PACKAGE_MANIFEST, manifest)
    return manifest


def get_package_manifest() -> dict:
    manifest = read_json(PACKAGE_MANIFEST, {}) if PACKAGE_MANIFEST.exists() else generate_package_manifest()
    manifest["latest_package"] = latest_package()
    manifest["latest_package_qa"] = latest_package_qa()
    return manifest




def get_release_candidate() -> dict | None:
    if not PACKAGE_CANDIDATE.exists():
        return None
    return read_json(PACKAGE_CANDIDATE, None)


def release_candidate_lock() -> dict:
    # Lock the currently built package. If none exists, build one first.
    if not latest_package():
        build_beta_package()
    pkg = latest_package()
    qa = verify_latest_package()
    manifest = get_package_manifest()
    readiness = release_readiness()
    candidate = {
        "product": "Harness Local",
        "version": VERSION,
        "status": "LOCKED" if qa.get("status") == "PASS" and readiness.get("status") == "PASS" else "WARN",
        "locked_at": now(),
        "package": pkg.get("name"),
        "package_path": pkg.get("path"),
        "download_url": pkg.get("download_url"),
        "package_size": pkg.get("size"),
        "package_sha256": pkg.get("sha256"),
        "qa_status": qa.get("status"),
        "qa_checked_at": qa.get("checked_at"),
        "qa_checks": [{"id": c.get("id"), "status": c.get("status")} for c in qa.get("checks", [])],
        "readiness_status": readiness.get("status"),
        "readiness_verdict": readiness.get("verdict"),
        "manifest_file_count": manifest.get("file_count"),
        "manifest_total_size": manifest.get("total_size"),
        "manifest_sha256": manifest.get("manifest_sha256"),
        "external_publish_status": "NOT_PUBLISHED",
    }
    write_json(PACKAGE_CANDIDATE, candidate)
    audit("release.candidate_locked", {"package": candidate.get("package"), "sha256": candidate.get("package_sha256"), "status": candidate.get("status")})
    return candidate


def demo_workspace_path() -> Path:
    return DATA / "demo-workspace"


def demo_status() -> dict:
    ws_rows = read_json(WORKSPACES, [])
    tasks = read_jsonl(TASKS)
    runs = read_jsonl(RUNS)
    reports = list_reports()
    demo_ws = [w for w in ws_rows if w.get("demo") is True and w.get("path") == str(demo_workspace_path())]
    demo_tasks = [t for t in tasks if t.get("demo") is True]
    demo_runs = [r for r in runs if r.get("demo") is True]
    latest_report = None
    for rep in reports:
        if rep.get("name", "").startswith("report_demo_"):
            latest_report = rep
            break
    checks = [
        {"id": "demo_workspace", "label": "Demo workspace", "status": "PASS" if demo_ws and demo_workspace_path().exists() else "WARN", "summary": str(demo_workspace_path())},
        {"id": "demo_task", "label": "Demo task", "status": "PASS" if demo_tasks else "WARN", "summary": demo_tasks[-1].get("goal", "Run ./harness demo") if demo_tasks else "Run ./harness demo"},
        {"id": "demo_runs", "label": "Demo evidence runs", "status": "PASS" if len(demo_runs) >= 3 else "WARN", "summary": f"runs={len(demo_runs)}"},
        {"id": "demo_report", "label": "Demo report", "status": "PASS" if latest_report else "WARN", "summary": latest_report.get("name", "Run ./harness demo") if latest_report else "Run ./harness demo"},
    ]
    order = {"FAIL": 2, "WARN": 1, "PASS": 0}
    status = max((c["status"] for c in checks), key=lambda x: order.get(x, 1))
    return {
        "status": status,
        "version": VERSION,
        "checked_at": now(),
        "workspace_path": str(demo_workspace_path()),
        "workspace_count": len(demo_ws),
        "task_count": len(demo_tasks),
        "run_count": len(demo_runs),
        "latest_report": latest_report,
        "checks": checks,
        "verdict": "3-minute Demo PASS: sample workspace, task, evidence runs, and report exist." if status == "PASS" else "Run ./harness demo to create the 3-minute local demo.",
    }


def clean_demo() -> dict:
    demo_dir = demo_workspace_path()
    before = demo_status()
    ws_rows = read_json(WORKSPACES, [])
    kept_ws = [w for w in ws_rows if not (w.get("demo") is True or w.get("path") == str(demo_dir))]
    removed_ws = len(ws_rows) - len(kept_ws)
    write_json(WORKSPACES, kept_ws)
    task_rows = read_jsonl(TASKS)
    kept_tasks = [t for t in task_rows if t.get("demo") is not True]
    removed_tasks = len(task_rows) - len(kept_tasks)
    rewrite_jsonl(TASKS, kept_tasks)
    run_rows = read_jsonl(RUNS)
    kept_runs = [r for r in run_rows if r.get("demo") is not True]
    removed_runs = len(run_rows) - len(kept_runs)
    rewrite_jsonl(RUNS, kept_runs)
    removed_reports = 0
    for path in REPORTS.glob("report_demo_*.md"):
        try:
            path.unlink()
            removed_reports += 1
        except FileNotFoundError:
            pass
    removed_files = 0
    if demo_dir.exists() and demo_dir.is_dir() and demo_dir.resolve().is_relative_to(DATA.resolve()):
        shutil.rmtree(demo_dir)
        removed_files = 1
    result = {
        "status": "PASS",
        "version": VERSION,
        "cleaned_at": now(),
        "before": before,
        "removed": {"workspaces": removed_ws, "tasks": removed_tasks, "runs": removed_runs, "reports": removed_reports, "demo_workspace_dir": removed_files},
        "after": demo_status(),
        "verdict": "Demo reset PASS: generated demo records and demo workspace removed.",
    }
    audit("demo.cleaned", result.get("removed", {}))
    return result


def run_demo() -> dict:
    demo_dir = demo_workspace_path()
    demo_dir.mkdir(parents=True, exist_ok=True)
    readme = demo_dir / "README.md"
    readme.write_text("""# Harness Local 3-minute Demo Workspace

This is a generated local-only demo workspace for Harness Local internal beta validation.

## What it proves

- Add a local workspace without cloud upload.
- Create a sample task.
- Run read-only evidence collection.
- Generate a safe audit report.

No credentials, no destructive commands, no external publishing.
""", encoding="utf-8")
    (demo_dir / "sample.txt").write_text("Harness Local demo artifact. Safe to inspect.\n", encoding="utf-8")
    rows = read_json(WORKSPACES, [])
    existing = None
    for ws in rows:
        if ws.get("demo") is True and ws.get("path") == str(demo_dir):
            existing = ws
            break
    scan = scan_workspace(str(demo_dir))
    if existing:
        existing.update({"name": "Harness Demo Workspace", "scan": scan, "updated_at": now(), "archived": False})
        ws = existing
    else:
        ws = {"id": "demo_ws_" + uuid.uuid4().hex[:8], "name": "Harness Demo Workspace", "path": str(demo_dir), "scan": scan, "created_at": now(), "updated_at": now(), "archived": False, "demo": True}
        rows.append(ws)
    write_json(WORKSPACES, rows)
    task = {"id": "demo_task_" + uuid.uuid4().hex[:8], "workspace_id": ws["id"], "goal": "Run 3-minute local beta demo: scan, git status, boundary check, and safe audit report.", "status": "DONE", "steps": plan_steps("demo safe audit", ws), "created_at": now(), "updated_at": now(), "demo": True}
    append_jsonl(TASKS, task)
    run_specs = [
        ("context_scan", scan_workspace(str(demo_dir))),
        ("git_status", run_git_status(str(demo_dir))),
        ("package_boundary_scan", scan_package_boundary(str(demo_dir))),
    ]
    run_ids = []
    for runner, payload in run_specs:
        run = {"id": "demo_run_" + uuid.uuid4().hex[:8], "task_id": task["id"], "workspace_id": ws["id"], "runner": runner, "status": "DONE" if payload.get("status", "PASS") in {"PASS", "DONE"} else payload.get("status", "DONE"), "created_at": now(), "stdout": json.dumps(payload, ensure_ascii=False, indent=2)[:4000], "stderr": "", "demo": True}
        append_jsonl(RUNS, run)
        run_ids.append(run["id"])
    report = make_safe_audit_report(ws, task)
    report_path = Path(report["path"])
    demo_report = REPORTS / ("report_demo_" + uuid.uuid4().hex[:10] + ".md")
    shutil.copyfile(report_path, demo_report)
    report = {"id": demo_report.stem, "created_at": now(), "summary": "3-minute demo safe audit PASS", "path": str(demo_report), "url": f"/reports/{demo_report.name}", "boundary": report.get("boundary")}
    task["last_run_id"] = run_ids[-1] if run_ids else ""
    task["report_id"] = report["id"]
    update_task(task["id"], last_run_id=task.get("last_run_id"), report_id=report["id"], status="DONE")
    result = demo_status()
    result.update({"demo_workspace": ws, "demo_task": task, "demo_runs": run_ids, "demo_report": report})
    audit("demo.ran", {"status": result.get("status"), "workspace": ws.get("id"), "task": task.get("id"), "report": report.get("id")})
    return result


def latest_evidence_pack() -> dict | None:
    if not EVIDENCE_INDEX.exists():
        return None
    return read_json(EVIDENCE_INDEX, {}) or None


def _copy_json_to(path: Path, name: str, data: dict) -> Path:
    target = path / name
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def export_evidence_pack() -> dict:
    # Ensure core local evidence exists and is current. This remains local-only.
    if demo_status().get("status") != "PASS":
        run_demo()
    expected_package = f"harness-local-v{VERSION}-beta.zip"
    current_package = latest_package()
    if not current_package or current_package.get("name") != expected_package:
        build_beta_package()
    qa = verify_latest_package()
    candidate = release_candidate_lock()
    doctor = doctor_check()
    demo = demo_status()
    summary = release_summary()
    manifest = get_package_manifest()
    pack_id = "evidence_v" + VERSION.replace(".", "_") + "_" + time.strftime("%Y%m%d%H%M%S")
    pack_dir = EVIDENCE / pack_id
    pack_dir.mkdir(parents=True, exist_ok=True)
    files = []
    def add_json(name, data):
        target = _copy_json_to(pack_dir, name, data)
        files.append({"path": name, "size": target.stat().st_size, "sha256": _sha256_file(target)})
    add_json("release-summary.json", summary)
    add_json("package-manifest.json", manifest)
    add_json("package-qa.json", qa)
    add_json("release-candidate.json", candidate)
    add_json("doctor.json", doctor)
    add_json("demo-summary.json", demo)
    report = demo.get("latest_report") or {}
    if report.get("path") and Path(report["path"]).exists():
        target = pack_dir / "demo-report.md"
        shutil.copyfile(report["path"], target)
        files.append({"path": "demo-report.md", "size": target.stat().st_size, "sha256": _sha256_file(target)})
    readme = pack_dir / "README.md"
    readme.write_text("""# Harness Local Evidence Pack

This evidence pack is generated locally. It is not uploaded or externally published by Harness Local.

Contents:
- release-summary.json
- package-manifest.json
- package-qa.json
- release-candidate.json
- doctor.json
- demo-summary.json
- demo-report.md when available
- SHA256SUMS

Safety boundary: local-first, no credential read, no destructive command, no cloud upload.
""", encoding="utf-8")
    files.append({"path": "README.md", "size": readme.stat().st_size, "sha256": _sha256_file(readme)})
    sha_lines = [f"{f['sha256']}  {f['path']}" for f in sorted(files, key=lambda x: x["path"])]
    sums = pack_dir / "SHA256SUMS"
    sums.write_text("\n".join(sha_lines) + "\n", encoding="utf-8")
    files.append({"path": "SHA256SUMS", "size": sums.stat().st_size, "sha256": _sha256_file(sums)})
    boundary = audit_zip_paths([str(pack_dir.relative_to(ROOT)) + "/" + f["path"] for f in files])
    result = {
        "status": "PASS" if qa.get("status") == "PASS" and candidate.get("status") == "LOCKED" and doctor.get("status") == "PASS" and demo.get("status") == "PASS" and boundary.get("status") == "PASS" else "WARN",
        "version": VERSION,
        "exported_at": now(),
        "pack_id": pack_id,
        "path": str(pack_dir),
        "url": f"/evidence/{pack_id}/README.md",
        "files": sorted(files, key=lambda x: x["path"]),
        "file_count": len(files),
        "boundary": boundary,
        "summary": {
            "package": (latest_package() or {}).get("name"),
            "package_sha256": (latest_package() or {}).get("sha256"),
            "qa": qa.get("status"),
            "candidate": candidate.get("status"),
            "doctor": doctor.get("status"),
            "demo": demo.get("status"),
        },
        "verdict": "Evidence Pack PASS: local evidence directory exported; not uploaded." if boundary.get("status") == "PASS" else "Evidence Pack WARN/FAIL: review boundary before sharing.",
    }
    write_json(EVIDENCE_INDEX, result)
    audit("evidence.exported", {"pack_id": pack_id, "status": result.get("status"), "file_count": len(files)})
    return result


def _clean_feedback_text(value, limit: int = 2000) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if len(text) > limit:
        text = text[:limit] + "…"
    return text


def submit_feedback(data: dict) -> dict:
    """Store internal beta feedback locally. No network, no upload."""
    rating_raw = data.get("rating", "")
    try:
        rating = int(rating_raw) if str(rating_raw).strip() else None
    except Exception:
        rating = None
    if rating is not None:
        rating = max(1, min(5, rating))
    item = {
        "id": "fb_" + uuid.uuid4().hex[:10],
        "created_at": now(),
        "version": VERSION,
        "role": _clean_feedback_text(data.get("role"), 80),
        "rating": rating,
        "works": _clean_feedback_text(data.get("works"), 1200),
        "issues": _clean_feedback_text(data.get("issues"), 2000),
        "wishlist": _clean_feedback_text(data.get("wishlist"), 1600),
        "contact": _clean_feedback_text(data.get("contact"), 120),
        "local_only": True,
    }
    append_jsonl(FEEDBACK, item)
    audit("feedback.submitted", {"id": item["id"], "rating": item.get("rating"), "version": VERSION})
    return {"status": "PASS", "version": VERSION, "feedback": item, "verdict": "Feedback saved locally to data/feedback.jsonl; not uploaded."}


def feedback_items() -> list[dict]:
    return read_jsonl(FEEDBACK)


def latest_feedback_summary() -> dict | None:
    path = EVIDENCE / "FEEDBACK-SUMMARY.md"
    if not path.exists():
        return None
    items = feedback_items()
    return {"status": "PASS", "version": VERSION, "path": str(path), "url": "/evidence/FEEDBACK-SUMMARY.md", "size": path.stat().st_size, "feedback_count": len(items)}


def export_feedback_summary() -> dict:
    """Export local feedback into dist/evidence/FEEDBACK-SUMMARY.md."""
    items = feedback_items()
    by_rating = {}
    for item in items:
        key = str(item.get("rating") or "unrated")
        by_rating[key] = by_rating.get(key, 0) + 1
    avg = None
    ratings = [x.get("rating") for x in items if isinstance(x.get("rating"), int)]
    if ratings:
        avg = round(sum(ratings) / len(ratings), 2)
    lines = [
        "# Harness Local 内部试用反馈汇总",
        "",
        f"生成时间：{now()}",
        f"版本：v{VERSION}",
        "",
        "## 安全边界",
        "",
        "- 反馈只保存在本机 `data/feedback.jsonl`。",
        "- 本摘要只导出到本机 `dist/evidence/FEEDBACK-SUMMARY.md`。",
        "- 不上传、不外发、不读取凭证。",
        "",
        "## 统计",
        "",
        f"- 反馈条数：{len(items)}",
        f"- 平均评分：{avg if avg is not None else 'N/A'}",
        f"- 评分分布：`{json.dumps(by_rating, ensure_ascii=False, sort_keys=True)}`",
        "",
        "## 明细",
        "",
    ]
    if not items:
        lines += ["暂无反馈。", ""]
    else:
        for i, item in enumerate(items, 1):
            lines += [
                f"### {i}. {item.get('id')} · {item.get('created_at')}",
                "",
                f"- 角色：{item.get('role') or '-'}",
                f"- 评分：{item.get('rating') if item.get('rating') is not None else '-'}",
                f"- 联系方式：{item.get('contact') or '-'}",
                "",
                "**有效点**",
                "",
                item.get("works") or "-",
                "",
                "**问题/卡点**",
                "",
                item.get("issues") or "-",
                "",
                "**希望补充**",
                "",
                item.get("wishlist") or "-",
                "",
            ]
    out = EVIDENCE / "FEEDBACK-SUMMARY.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    result = {"status": "PASS", "version": VERSION, "generated_at": now(), "path": str(out), "url": "/evidence/FEEDBACK-SUMMARY.md", "size": out.stat().st_size, "feedback_count": len(items), "average_rating": avg, "rating_distribution": by_rating, "verdict": "Feedback summary PASS: local-only feedback summary exported."}
    audit("feedback.exported", {"status": result.get("status"), "count": len(items), "path": str(out)})
    return result


def generate_trial_note() -> dict:
    # Keep this local-only. It writes a markdown handoff note under dist/evidence.
    if not latest_package() or (latest_package() or {}).get("name") != f"harness-local-v{VERSION}-beta.zip":
        build_beta_package()
    qa = verify_latest_package()
    candidate = release_candidate_lock()
    demo = demo_status()
    if demo.get("status") != "PASS":
        demo = run_demo()
    evidence = latest_evidence_pack() or export_evidence_pack()
    doctor = doctor_check()
    latest = latest_package() or {}
    report = (demo_status().get("latest_report") or {})
    note_path = EVIDENCE / "TRIAL-NOTE.md"
    note = f"""# Harness Local 内部 beta 本地试用说明

生成时间：{now()}  
版本：v{VERSION}  
包名：`{latest.get('name', '')}`  
SHA256：`{latest.get('sha256', '')}`

## 一句话说明

Harness Local 是本地优先的内部 beta 候选包。本试用流程只在本机运行，不上传项目文件，不读取凭证，不对外发布。

## 快速开始

```bash
unzip {latest.get('name', 'harness-local-v' + VERSION + '-beta.zip')}
cd harness-local-v{VERSION}-beta
./harness first-run
./harness open
```

浏览器打开：

```text
http://127.0.0.1:8788/first-run
http://127.0.0.1:8788/release
```

## 验收摘要

| Gate | Status |
|---|---|
| Package QA | {qa.get('status')} |
| Release Candidate | {candidate.get('status')} |
| Doctor | {doctor.get('status')} |
| Demo | {demo.get('status')} |
| Evidence Pack | {evidence.get('status')} |

## 本地证据

- Evidence README: `{evidence.get('url', '')}`
- Demo Report: `{report.get('url', '')}`
- Package download: `/packages/{latest.get('name', '')}`

## 安全边界

- 不上传项目文件。
- 不读取或保存 API key / token / 凭证。
- 不执行 destructive command。
- 不对外发布。
- `clean-demo` 只清理 Harness 生成的 demo workspace/task/runs/reports。
- Evidence Pack 只写入本地 `dist/evidence/`。

## 常见问题

### 1. 需要联网吗？
不需要。当前内部 beta 验收链路是本地运行。

### 2. 会改我的真实项目吗？
不会。Demo 使用 `data/demo-workspace`，不会触碰用户真实项目。

### 3. Evidence Pack 会被上传吗？
不会。只写到本机 `dist/evidence/`。

### 4. 怎么确认包没被替换？
核对 SHA256：

```text
{latest.get('sha256', '')}  {latest.get('name', '')}
```

### 5. 试用者只需要记哪条命令？

```bash
./harness first-run
```
"""
    note_path.write_text(note, encoding="utf-8")
    result = {
        "status": "PASS" if qa.get("status") == "PASS" and candidate.get("status") == "LOCKED" and doctor.get("status") == "PASS" and demo.get("status") == "PASS" and evidence.get("status") == "PASS" else "WARN",
        "version": VERSION,
        "generated_at": now(),
        "path": str(note_path),
        "url": "/evidence/TRIAL-NOTE.md",
        "size": note_path.stat().st_size,
        "sha256": _sha256_file(note_path),
        "summary": {
            "package": latest.get("name"),
            "package_sha256": latest.get("sha256"),
            "qa": qa.get("status"),
            "candidate": candidate.get("status"),
            "doctor": doctor.get("status"),
            "demo": demo.get("status"),
            "evidence": evidence.get("status"),
        },
        "verdict": "Trial Note PASS: internal trial handoff markdown generated locally.",
    }
    audit("trial_note.generated", {"status": result.get("status"), "path": str(note_path), "sha256": result.get("sha256")})
    return result


def generate_print_checklist() -> dict:
    """Generate a printable offline verification checklist under dist/evidence/CHECKLIST.html."""
    if not latest_package() or (latest_package() or {}).get("name") != f"harness-local-v{VERSION}-beta.zip":
        build_beta_package()
    qa = verify_latest_package()
    candidate = release_candidate_lock()
    demo = demo_status()
    if demo.get("status") != "PASS":
        demo = run_demo()
    evidence = latest_evidence_pack() or export_evidence_pack()
    trial = latest_trial_note() or generate_trial_note()
    doctor = doctor_check()
    latest = latest_package() or {}
    report = (demo_status().get("latest_report") or {})
    summary = release_summary()
    now_ts = now()
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>Harness Local v{VERSION} 内部核验单</title>
  <style>
    @page {{ size: A4; margin: 15mm; }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif; font-size: 12pt; line-height: 1.6; color: #1e1e2e; background: #fff; padding: 0; }}
    .page {{ max-width: 210mm; margin: 0 auto; padding: 15mm 20mm; }}
    h1 {{ font-size: 18pt; margin-bottom: 4pt; }}
    .sub {{ font-size: 10pt; color: #666; margin-bottom: 12pt; }}
    .meta table {{ width: 100%; border-collapse: collapse; margin-bottom: 14pt; }}
    .meta th, .meta td {{ text-align: left; padding: 3pt 6pt; font-size: 10pt; border-bottom: 1px solid #eee; }}
    .meta th {{ width: 120pt; color: #555; font-weight: 500; }}
    .gates table {{ width: 100%; border-collapse: collapse; margin-bottom: 14pt; }}
    .gates th {{ background: #f4f4f5; font-weight: 600; font-size: 10pt; padding: 5pt 8pt; text-align: left; border-bottom: 2px solid #ddd; }}
    .gates td {{ font-size: 10pt; padding: 5pt 8pt; border-bottom: 1px solid #eee; }}
    .gates .status {{ font-weight: 600; }}
    .gates .status.pass {{ color: #16a34a; }}
    .gates .status.warn {{ color: #d97706; }}
    .gates .status.fail {{ color: #dc2626; }}
    .footer {{ font-size: 9pt; color: #999; margin-top: 20pt; border-top: 1px solid #ddd; padding-top: 8pt; }}
    @media print {{ .no-print {{ display: none; }} }}
    button {{ font-size: 10pt; padding: 6pt 16pt; background: #2563eb; color: #fff; border: none; border-radius: 4pt; cursor: pointer; }}
    button:hover {{ background: #1d4ed8; }}
  </style>
</head>
<body>
<div class="page">
  <h1>Harness Local 内部试用核验单</h1>
  <p class="sub">版本 v{VERSION} · 生成时间 {now_ts} · 本地通过状态</p>

  <div class="no-print" style="margin-bottom:12pt;"><button onclick="window.print()">🖨 打印 / Print</button></div>

  <div class="meta"><table>
    <tr><th>包名</th><td>{latest.get('name', '')}</td></tr>
    <tr><th>SHA256</th><td><code style="font-size:9pt;word-break:break-all;">{latest.get('sha256', '')}</code></td></tr>
    <tr><th>包大小</th><td>{latest.get('size', '')} bytes</td></tr>
    <tr><th>Release Status</th><td>{summary.get('status', '')}</td></tr>
  </table></div>

  <div class="gates"><table>
    <thead><tr><th style="width:24pt;">#</th><th>核验门</th><th style="width:80pt;">状态</th><th>备注</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>3‑minute Demo</td><td class="status {'pass' if (summary.get('demo') or {}).get('status')=='PASS' else 'warn'}">{summary.get('demo',{}).get('status','-')}</td><td>{summary.get('demo',{}).get('summary','')}</td></tr>
      <tr><td>2</td><td>Package Build</td><td class="status {'pass' if latest.get('name') else 'warn'}">{"PASS" if latest.get('name') else "WARN"}</td><td>{latest.get('name', '未构建')}</td></tr>
      <tr><td>3</td><td>Package QA</td><td class="status {'pass' if (summary.get('package_qa') or {}).get('status')=='PASS' else 'warn'}">{summary.get('package_qa',{}).get('status','-')}</td><td>{summary.get('package_qa',{}).get('summary','')}</td></tr>
      <tr><td>4</td><td>Release Candidate Lock</td><td class="status {'pass' if (summary.get('release_candidate') or {}).get('status')=='LOCKED' else 'warn'}">{summary.get('release_candidate',{}).get('status','-')}</td><td>{summary.get('release_candidate',{}).get('package_sha256','')[:16]+'...' if summary.get('release_candidate',{}).get('package_sha256') else ''}</td></tr>
      <tr><td>5</td><td>Doctor</td><td class="status {'pass' if (summary.get('doctor') or {}).get('status')=='PASS' else 'warn'}">{summary.get('doctor',{}).get('status','-')}</td><td>{summary.get('doctor',{}).get('summary','')}</td></tr>
      <tr><td>6</td><td>Evidence Pack</td><td class="status {'pass' if (summary.get('evidence_pack') or {}).get('status')=='PASS' else 'warn'}">{summary.get('evidence_pack',{}).get('status','-')}</td><td>{summary.get('evidence_pack',{}).get('summary','')}</td></tr>
      <tr><td>7</td><td>Trial Note</td><td class="status {'pass' if (summary.get('trial_note') or {}).get('status')=='PASS' else 'warn'}">{summary.get('trial_note',{}).get('status','-')}</td><td>{summary.get('trial_note',{}).get('summary','')}</td></tr>
    </tbody>
  </table></div>

  <div class="meta"><table>
    <tr><th>安全边界</th><td>本流程只在本机运行，不上传项目文件，不读取凭证，不外发。</td></tr>
    <tr><th>证据路径</th><td><code style="font-size:9pt;word-break:break-all;">{evidence.get('url','') if isinstance(evidence,dict) else ''}</code></td></tr>
    <tr><th>核验路径</th><td><code style="font-size:9pt;word-break:break-all;">/{latest.get('name', '')}</code></td></tr>
    <tr><th>建议</th><td>所有门 PASS 后即可内部试用发放。某门 WARN 需要排查原因。</td></tr>
  </table></div>

  <div class="footer">Harness Local v{VERSION} · 本地核验单（可打印） · {now_ts}</div>
</div>
</body>
</html>"""
    checklist_path = EVIDENCE / "CHECKLIST.html"
    checklist_path.write_text(html, encoding="utf-8")
    gates_all_pass = all(
        (summary.get(g, {}) if isinstance(summary.get(g), dict) else {}).get("status") in ("PASS", "LOCKED", None)
        for g in ("demo", "package_qa", "release_candidate", "doctor", "evidence_pack", "trial_note")
    ) and latest.get("name") is not None
    result = {
        "status": "PASS" if gates_all_pass else "WARN",
        "version": VERSION,
        "generated_at": now_ts,
        "path": str(checklist_path),
        "url": "/evidence/CHECKLIST.html",
        "size": checklist_path.stat().st_size,
        "summary": {
            "package": latest.get("name"),
            "package_sha256": latest.get("sha256"),
            "qa": qa.get("status"),
            "candidate": candidate.get("status"),
            "doctor": doctor.get("status"),
            "demo": demo.get("status"),
            "evidence": evidence.get("status") if isinstance(evidence, dict) else evidence.get("status"),
            "trial_note": trial.get("status") if isinstance(trial, dict) else trial.get("status"),
        },
        "verdict": "Print Checklist PASS: printable offline verification page generated locally.",
    }
    audit("print_checklist.generated", {"status": result.get("status"), "path": str(checklist_path)})
    return result



def latest_trial_bundle() -> dict | None:
    bundle_dir = EVIDENCE / "TRIAL-BUNDLE"
    index = bundle_dir / "index.html"
    readme = bundle_dir / "README.md"
    if not index.exists() or not readme.exists():
        return None
    files = []
    for child in sorted(bundle_dir.iterdir(), key=lambda x: x.name.lower()):
        if child.is_file():
            files.append({"name": child.name, "path": str(child), "size": child.stat().st_size, "sha256": _sha256_file(child)})
    return {
        "status": "PASS",
        "version": VERSION,
        "path": str(bundle_dir),
        "url": "/evidence/TRIAL-BUNDLE/index.html",
        "readme_url": "/evidence/TRIAL-BUNDLE/README.md",
        "file_count": len(files),
        "files": files,
    }


def _copy_if_exists(src: Path, dst: Path, files: list[dict], name: str | None = None) -> None:
    if src and src.exists() and src.is_file():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        files.append({"path": name or dst.name, "size": dst.stat().st_size, "sha256": _sha256_file(dst)})


def generate_trial_bundle() -> dict:
    """Generate a local-only trial bundle folder under dist/evidence/TRIAL-BUNDLE."""
    if not latest_package() or (latest_package() or {}).get("name") != f"harness-local-v{VERSION}-beta.zip":
        build_beta_package()
    qa = verify_latest_package()
    candidate = release_candidate_lock()
    demo = demo_status()
    if demo.get("status") != "PASS":
        demo = run_demo()
    evidence = export_evidence_pack()
    trial = generate_trial_note()
    checklist = generate_print_checklist()
    feedback = export_feedback_summary()
    doctor = doctor_check()
    summary = release_summary()
    latest = latest_package() or {}
    report = demo_status().get("latest_report") or {}

    bundle_dir = EVIDENCE / "TRIAL-BUNDLE"
    if bundle_dir.exists():
        shutil.rmtree(bundle_dir)
    bundle_dir.mkdir(parents=True, exist_ok=True)
    files: list[dict] = []

    def add_json(name: str, data: dict):
        target = _copy_json_to(bundle_dir, name, data)
        files.append({"path": name, "size": target.stat().st_size, "sha256": _sha256_file(target)})

    add_json("release-summary.json", summary)
    add_json("package-qa.json", qa)
    add_json("release-candidate.json", candidate)
    add_json("doctor.json", doctor)
    add_json("demo-summary.json", demo)
    add_json("trial-bundle-summary.json", {"version": VERSION, "generated_at": now(), "package": latest, "evidence": evidence, "trial_note": trial, "checklist": checklist, "feedback": feedback})

    _copy_if_exists(EVIDENCE / "TRIAL-NOTE.md", bundle_dir / "TRIAL-NOTE.md", files)
    _copy_if_exists(EVIDENCE / "CHECKLIST.html", bundle_dir / "CHECKLIST.html", files)
    _copy_if_exists(EVIDENCE / "FEEDBACK-SUMMARY.md", bundle_dir / "FEEDBACK-SUMMARY.md", files)
    if report.get("path"):
        _copy_if_exists(Path(report["path"]), bundle_dir / "demo-report.md", files)
    if evidence.get("path"):
        _copy_if_exists(Path(evidence["path"]) / "README.md", bundle_dir / "evidence-readme.md", files)
        _copy_if_exists(Path(evidence["path"]) / "SHA256SUMS", bundle_dir / "evidence-SHA256SUMS", files)

    readme = bundle_dir / "README.md"
    readme.write_text(f"""# Harness Local Trial Bundle

生成时间：{now()}  
版本：v{VERSION}  
包名：`{latest.get('name', '')}`  
SHA256：`{latest.get('sha256', '')}`

## 用途

这是内部试用的本地证据包索引目录，聚合 Trial Note、Checklist、Feedback Summary、Evidence README、Demo Report 与关键 JSON。

## 安全边界

- 只生成在本机 `dist/evidence/TRIAL-BUNDLE/`。
- 不上传、不外发、不读取凭证。
- 不压进 beta zip，不自动分享。
- 反馈原始 JSONL 不复制进 bundle；只包含导出的 `FEEDBACK-SUMMARY.md`。

## 文件

- `index.html`：浏览器入口
- `TRIAL-NOTE.md`：内部试用说明
- `CHECKLIST.html`：可打印核验单
- `FEEDBACK-SUMMARY.md`：本地反馈摘要
- `evidence-readme.md`：Evidence Pack README 副本
- `demo-report.md`：Demo 报告副本
- `release-summary.json` / `package-qa.json` / `release-candidate.json` / `doctor.json` / `demo-summary.json`
- `SHA256SUMS`：本目录文件校验

## 当前状态

- Package QA: {qa.get('status')}
- Release Candidate: {candidate.get('status')}
- Doctor: {doctor.get('status')}
- Demo: {demo.get('status')}
- Evidence: {evidence.get('status')}
- Trial Note: {trial.get('status')}
- Checklist: {checklist.get('status')}
- Feedback Summary: {feedback.get('status')}
""", encoding="utf-8")
    files.append({"path": "README.md", "size": readme.stat().st_size, "sha256": _sha256_file(readme)})

    links = [
        ("Trial Note", "TRIAL-NOTE.md", trial.get("status")),
        ("Printable Checklist", "CHECKLIST.html", checklist.get("status")),
        ("Feedback Summary", "FEEDBACK-SUMMARY.md", feedback.get("status")),
        ("Evidence README", "evidence-readme.md", evidence.get("status")),
        ("Demo Report", "demo-report.md", demo.get("status")),
        ("Release Summary JSON", "release-summary.json", summary.get("status")),
        ("Package QA JSON", "package-qa.json", qa.get("status")),
        ("Release Candidate JSON", "release-candidate.json", candidate.get("status")),
        ("Doctor JSON", "doctor.json", doctor.get("status")),
    ]
    cards = "\n".join([f'<a class="card" href="{href}" target="_blank"><span>{label}</span><b>{status or "OPEN"}</b><small>{href}</small></a>' for label, href, status in links])
    html = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Harness Local v{VERSION} Trial Bundle</title>
  <style>
    body {{ margin:0; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC',sans-serif; background:#0f172a; color:#e5e7eb; }}
    main {{ max-width:1100px; margin:0 auto; padding:40px 20px; }}
    .hero {{ border:1px solid rgba(148,163,184,.3); border-radius:24px; padding:28px; background:linear-gradient(135deg,rgba(37,99,235,.22),rgba(20,184,166,.16)); }}
    .eyebrow {{ color:#93c5fd; text-transform:uppercase; letter-spacing:.16em; font-size:12px; }}
    h1 {{ margin:.2em 0; font-size:42px; }}
    code {{ color:#bfdbfe; word-break:break-all; }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px; margin-top:22px; }}
    .card {{ display:block; padding:18px; border-radius:18px; background:rgba(15,23,42,.88); border:1px solid rgba(148,163,184,.28); color:#e5e7eb; text-decoration:none; }}
    .card span {{ display:block; color:#cbd5e1; }} .card b {{ display:block; margin:10px 0; color:#86efac; }} .card small {{ color:#94a3b8; }}
    .panel {{ margin-top:18px; padding:18px; border-radius:18px; border:1px solid rgba(148,163,184,.28); background:rgba(15,23,42,.68); }}
    footer {{ margin-top:28px; color:#94a3b8; font-size:13px; }}
  </style>
</head>
<body><main>
  <section class="hero"><p class="eyebrow">Harness Local v{VERSION}</p><h1>Trial Bundle</h1>
  <p>内部试用本地证据包。只生成在本机 <code>dist/evidence/TRIAL-BUNDLE/</code>；不上传、不外发、不读取凭证、不压进 beta zip。</p>
  <p>Package: <code>{latest.get('name','')}</code><br/>SHA256: <code>{latest.get('sha256','')}</code></p></section>
  <section class="grid">{cards}</section>
  <section class="panel"><h2>Safety Boundary</h2><ul><li>Local-only folder export.</li><li>No cloud upload.</li><li>No credential read.</li><li>Raw feedback JSONL is not copied; only FEEDBACK-SUMMARY.md is included.</li></ul></section>
  <footer>Generated {now()} · Harness Local 内部 Beta 候选</footer>
</main></body></html>"""
    index = bundle_dir / "index.html"
    index.write_text(html, encoding="utf-8")
    files.append({"path": "index.html", "size": index.stat().st_size, "sha256": _sha256_file(index)})

    sha_lines = [f"{f['sha256']}  {f['path']}" for f in sorted(files, key=lambda x: x["path"])]
    sums = bundle_dir / "SHA256SUMS"
    sums.write_text("\n".join(sha_lines) + "\n", encoding="utf-8")
    files.append({"path": "SHA256SUMS", "size": sums.stat().st_size, "sha256": _sha256_file(sums)})

    boundary = audit_zip_paths([str(bundle_dir.relative_to(ROOT)) + "/" + f["path"] for f in files])
    gates = [qa.get("status"), candidate.get("status"), doctor.get("status"), demo.get("status"), evidence.get("status"), trial.get("status"), checklist.get("status"), feedback.get("status"), boundary.get("status")]
    ok = all(x in {"PASS", "LOCKED"} for x in gates)
    result = {
        "status": "PASS" if ok else "WARN",
        "version": VERSION,
        "generated_at": now(),
        "path": str(bundle_dir),
        "url": "/evidence/TRIAL-BUNDLE/index.html",
        "readme_url": "/evidence/TRIAL-BUNDLE/README.md",
        "file_count": len(files),
        "files": sorted(files, key=lambda x: x["path"]),
        "boundary": boundary,
        "summary": {
            "package": latest.get("name"),
            "package_sha256": latest.get("sha256"),
            "qa": qa.get("status"),
            "candidate": candidate.get("status"),
            "doctor": doctor.get("status"),
            "demo": demo.get("status"),
            "evidence": evidence.get("status"),
            "trial_note": trial.get("status"),
            "print_checklist": checklist.get("status"),
            "feedback_summary": feedback.get("status"),
        },
        "verdict": "Trial Bundle PASS: local trial handoff folder generated; not uploaded or embedded in zip." if ok else "Trial Bundle WARN: review bundle gates before sharing locally.",
    }
    audit("trial_bundle.generated", {"status": result.get("status"), "path": str(bundle_dir), "file_count": len(files)})
    return result


def latest_print_checklist() -> dict | None:
    checklist_path = EVIDENCE / "CHECKLIST.html"
    if not checklist_path.exists():
        return None
    return {"status": "PASS", "version": VERSION, "path": str(checklist_path), "url": "/evidence/CHECKLIST.html", "size": checklist_path.stat().st_size}




def latest_trial_note() -> dict | None:
    note_path = EVIDENCE / "TRIAL-NOTE.md"
    if not note_path.exists():
        return None
    return {"status": "PASS", "version": VERSION, "path": str(note_path), "url": "/evidence/TRIAL-NOTE.md", "size": note_path.stat().st_size, "sha256": _sha256_file(note_path)}


def first_run(port: int | None = None, open_browser: bool = False) -> dict:
    steps = []
    def add_step(step_id: str, label: str, fn):
        try:
            result = fn()
            status = result.get("status", "PASS") if isinstance(result, dict) else "PASS"
            steps.append({"id": step_id, "label": label, "status": status, "result": result})
            return result
        except Exception as exc:
            steps.append({"id": step_id, "label": label, "status": "FAIL", "error": str(exc)})
            return {"status": "FAIL", "error": str(exc)}

    add_step("clean_demo", "Reset demo", clean_demo)
    add_step("demo", "Run 3-minute demo", run_demo)
    add_step("package_build", "Build beta package", build_beta_package)
    add_step("package_qa", "Verify package", verify_latest_package)
    add_step("candidate_lock", "Lock release candidate", release_candidate_lock)
    add_step("doctor", "Run doctor", doctor_check)
    evidence = add_step("evidence_pack", "Export evidence pack", export_evidence_pack)
    trial_note = add_step("trial_note", "Generate trial note", generate_trial_note)
    print_checklist = add_step("print_checklist", "Generate printable checklist", generate_print_checklist)
    trial_bundle = add_step("trial_bundle", "Generate trial bundle", generate_trial_bundle)
    summary = release_summary()
    port = port or int(os.environ.get("HARNESS_PORT", "8788"))
    release_url = f"http://127.0.0.1:{port}/release"
    evidence_url = f"http://127.0.0.1:{port}" + (evidence.get("url") or "") if evidence.get("url") else ""
    trial_note_url = f"http://127.0.0.1:{port}" + (trial_note.get("url") or "") if trial_note.get("url") else ""
    checklist_url = f"http://127.0.0.1:{port}" + (print_checklist.get("url") or "") if print_checklist.get("url") else ""
    trial_bundle_url = f"http://127.0.0.1:{port}" + (trial_bundle.get("url") or "") if trial_bundle.get("url") else ""
    order = {"FAIL": 2, "WARN": 1, "PASS": 0, "LOCKED": 0, "DONE": 0}
    status = max((step.get("status", "WARN") for step in steps), key=lambda x: order.get(x, 1))
    result = {
        "status": "PASS" if status in {"PASS", "LOCKED", "DONE"} and summary.get("status") == "PASS" else status,
        "version": VERSION,
        "ran_at": now(),
        "steps": steps,
        "release_url": release_url,
        "evidence_url": evidence_url,
        "trial_note_url": trial_note_url,
        "checklist_url": checklist_url,
        "trial_bundle_url": trial_bundle_url,
        "summary": {
            "release": summary.get("status"),
            "package": (summary.get("latest_package") or {}).get("name"),
            "package_sha256": (summary.get("latest_package") or {}).get("sha256"),
            "qa": (summary.get("package_qa") or {}).get("status"),
            "candidate": (summary.get("release_candidate") or {}).get("status"),
            "doctor": (summary.get("doctor") or {}).get("status"),
            "demo": (summary.get("demo") or {}).get("status"),
            "evidence": (summary.get("evidence_pack") or {}).get("status"),
            "trial_note": (summary.get("trial_note") or {}).get("status"),
            "print_checklist": (summary.get("print_checklist") or {}).get("status"),
            "trial_bundle": (summary.get("trial_bundle") or {}).get("status"),
            "feedback_count": summary.get("feedback_count"),
        },
        "verdict": "First Run PASS: beta trial is ready. Open the local Release Center URL." if summary.get("status") == "PASS" else "First Run WARN/FAIL: review steps before beta handoff.",
    }
    audit("first_run.completed", {"status": result.get("status"), "steps": len(steps), "release_url": release_url})
    return result


def doctor_check() -> dict:
    checks = []
    checks.append({"id": "python", "label": "Python runtime", "status": "PASS", "summary": os.sys.version.split()[0]})
    checks.append({"id": "root", "label": "Package root", "status": "PASS" if ROOT.exists() else "FAIL", "summary": str(ROOT)})
    checks.append({"id": "server_file", "label": "Server file", "status": "PASS" if (ROOT / "app/server.py").exists() else "FAIL", "summary": "app/server.py"})
    readiness = release_readiness()
    checks.append({"id": "readiness", "label": "Release readiness", "status": readiness.get("status", "FAIL"), "summary": readiness.get("verdict", "")})
    is_packaging_checkout = not PACKAGE_MANIFEST.exists()
    if is_packaging_checkout:
        latest = latest_package()
        checks.append({"id": "latest_package", "label": "Latest package", "status": "PASS" if latest else "WARN", "summary": latest.get("name", "no package") if latest else "Run ./harness package-build"})
        qa = latest_package_qa()
        checks.append({"id": "package_qa", "label": "Package QA", "status": qa.get("status", "WARN") if qa else "WARN", "summary": qa.get("verdict", "Run ./harness package-verify") if qa else "Run ./harness package-verify"})
        candidate = get_release_candidate()
        candidate_ok = bool(candidate and latest and candidate.get("package") == latest.get("name") and candidate.get("package_sha256") == latest.get("sha256"))
        checks.append({"id": "release_candidate", "label": "Release Candidate", "status": "PASS" if candidate_ok else "WARN", "summary": candidate.get("package_sha256", "Run ./harness candidate-lock") if candidate else "Run ./harness candidate-lock"})
    port = int(os.environ.get("HARNESS_PORT", "8788"))
    checks.append({"id": "port_config", "label": "Port config", "status": "PASS" if 1 <= port <= 65535 else "FAIL", "summary": str(port)})
    guide = ROOT / "docs" / "HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md"
    checks.append({"id": "guide", "label": "Install guide", "status": "PASS" if guide.exists() else "FAIL", "summary": guide.name})
    if is_packaging_checkout:
        demo = demo_status()
        checks.append({"id": "demo", "label": "3-minute demo", "status": demo.get("status", "WARN"), "summary": demo.get("verdict", "Run ./harness demo")})
    order = {"FAIL": 2, "WARN": 1, "PASS": 0, "LOCKED": 0}
    status = max((c["status"] for c in checks), key=lambda x: order.get(x, 1))
    mode = "packaging_checkout" if is_packaging_checkout else "installed_package"
    verdict = "Doctor PASS: installed package runtime is ready." if (status == "PASS" and mode == "installed_package") else "Doctor PASS: local package is ready for internal beta handoff." if status == "PASS" else "Doctor WARN/FAIL: review checks before handoff."
    result = {"status": status, "version": VERSION, "mode": mode, "checked_at": now(), "checks": checks, "verdict": verdict}
    audit("doctor.checked", {"status": status, "mode": mode, "checks": len(checks)})
    return result


def release_summary() -> dict:
    manifest = get_package_manifest()
    latest = latest_package()
    qa = latest_package_qa()
    readiness = release_readiness()
    guide_rel = "docs/HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md"
    guide_path = ROOT / guide_rel
    candidate = get_release_candidate()
    candidate_ok = candidate and candidate.get("package") == (latest or {}).get("name") and candidate.get("package_sha256") == (latest or {}).get("sha256")
    doctor = doctor_check()
    demo = demo_status()
    evidence = latest_evidence_pack()
    trial_note = latest_trial_note()
    print_checklist = latest_print_checklist()
    feedback_summary = latest_feedback_summary()
    trial_bundle = latest_trial_bundle()
    feedback_count = len(feedback_items())
    checklist = [
        {"id": "release_readiness", "label": "Release readiness", "status": readiness.get("status", "UNKNOWN"), "summary": readiness.get("verdict", "")},
        {"id": "latest_package", "label": "Beta package", "status": "PASS" if latest else "WARN", "summary": latest.get("name", "No package built") if latest else "Build beta zip first"},
        {"id": "package_qa", "label": "Package QA", "status": qa.get("status", "WARN") if qa else "WARN", "summary": qa.get("verdict", "Run Verify latest zip") if qa else "Run Verify latest zip"},
        {"id": "install_guide", "label": "Install guide", "status": "PASS" if guide_path.exists() else "FAIL", "summary": guide_rel if guide_path.exists() else "missing"},
        {"id": "release_candidate_lock", "label": "Release Candidate lock", "status": "PASS" if candidate_ok else "WARN", "summary": candidate.get("package_sha256", "Lock RC after build") if candidate else "Lock RC after build"},
        {"id": "doctor", "label": "Doctor", "status": doctor.get("status", "WARN"), "summary": doctor.get("verdict", "Run ./harness doctor")},
        {"id": "demo", "label": "3-minute Demo", "status": demo.get("status", "WARN"), "summary": demo.get("verdict", "Run ./harness demo")},
        {"id": "evidence_pack", "label": "Evidence Pack", "status": evidence.get("status", "WARN") if evidence else "WARN", "summary": evidence.get("path", "Run ./harness export-evidence") if evidence else "Run ./harness export-evidence"},
        {"id": "trial_note", "label": "Trial Note", "status": trial_note.get("status", "WARN") if trial_note else "WARN", "summary": trial_note.get("path", "Run ./harness trial-note") if trial_note else "Run ./harness trial-note"},
        {"id": "print_checklist", "label": "Print Checklist", "status": print_checklist.get("status", "WARN") if print_checklist else "WARN", "summary": print_checklist.get("path", "Run ./harness print-checklist") if print_checklist else "Run ./harness print-checklist"},
        {"id": "feedback_capture", "label": "Feedback Capture", "status": "PASS", "summary": f"local feedback items={feedback_count}; export optional via ./harness feedback-export"},
        {"id": "trial_bundle", "label": "Trial Bundle", "status": trial_bundle.get("status", "WARN") if trial_bundle else "WARN", "summary": trial_bundle.get("path", "Run ./harness trial-bundle") if trial_bundle else "Run ./harness trial-bundle"},
    ]
    order = {"FAIL": 2, "WARN": 1, "PASS": 0, "DONE": 0, "ok": 0}
    status = max((c["status"] for c in checklist), key=lambda x: order.get(x, 1))
    return {
        "product": "Harness Local",
        "version": VERSION,
        "status": status,
        "generated_at": now(),
        "readiness": readiness,
        "manifest": {"file_count": manifest.get("file_count"), "total_size": manifest.get("total_size"), "sha256": manifest.get("manifest_sha256")},
        "latest_package": latest,
        "package_qa": qa,
        "install_guide": {"path": guide_rel, "exists": guide_path.exists(), "url": f"/docs/{Path(guide_rel).name}"},
        "release_candidate": ({**candidate, "url": "/release-candidate.json"} if candidate else None),
        "doctor": doctor,
        "demo": demo,
        "evidence_pack": evidence,
        "trial_note": trial_note,
        "print_checklist": print_checklist,
        "feedback_summary": feedback_summary,
        "trial_bundle": trial_bundle,
        "feedback_count": feedback_count,
        "checklist": checklist,
        "verdict": "Release candidate is internally shareable after QA PASS; not externally published." if status == "PASS" else "Release candidate needs fixes before sharing.",
    }


PACKAGE_FORBIDDEN_TOKENS = ["CREDENTIALS", "MEMORY.md", "openclaw", "workspace-main", "CEO", "ceo-memory", "FOS"]



def latest_package_qa() -> dict | None:
    if not PACKAGE_QA.exists():
        return None
    return read_json(PACKAGE_QA, {}) or None


def verify_latest_package() -> dict:
    pkg = latest_package()
    if not pkg:
        raise ValueError("no package has been built yet")
    zip_path = Path(pkg.get("path", ""))
    if not zip_path.exists() or not zip_path.is_file():
        raise ValueError("latest package file missing")
    actual_sha = _sha256_file(zip_path)
    checks = []
    checks.append({"id": "zip_exists", "status": "PASS", "summary": str(zip_path)})
    checks.append({"id": "sha256", "status": "PASS" if actual_sha == pkg.get("sha256") else "FAIL", "summary": actual_sha})
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = zf.namelist()
        audit_result = audit_zip_paths(names)
        checks.append({"id": "zip_path_audit", "status": audit_result.get("status"), "summary": f"hits={len(audit_result.get('hits', []))}", "details": audit_result})
        roots = sorted({Path(n).parts[0] for n in names if Path(n).parts})
        checks.append({"id": "single_root", "status": "PASS" if len(roots) == 1 else "FAIL", "summary": ",".join(roots)})
        required = ["README.md", "harness", "app/server.py", "app/static/index.html", "RELEASE-MANIFEST.json"]
        root = roots[0] if len(roots) == 1 else ""
        missing = [r for r in required if f"{root}/{r}" not in names]
        checks.append({"id": "required_entries", "status": "PASS" if not missing else "FAIL", "summary": f"missing={missing}"})
        manifest_status = "FAIL"
        manifest_summary = "missing manifest"
        try:
            manifest = json.loads(zf.read(f"{root}/RELEASE-MANIFEST.json").decode("utf-8"))
            manifest_status = "PASS" if manifest.get("version") == VERSION else "FAIL"
            manifest_summary = f"manifest_version={manifest.get('version')} file_count={manifest.get('file_count')}"
        except Exception as e:
            manifest_summary = str(e)
        checks.append({"id": "embedded_manifest", "status": manifest_status, "summary": manifest_summary})
    order = {"FAIL": 2, "WARN": 1, "PASS": 0}
    status = max((c["status"] for c in checks), key=lambda x: order.get(x, 2))
    result = {
        "status": status,
        "package": pkg.get("name"),
        "path": str(zip_path),
        "size": zip_path.stat().st_size,
        "sha256": actual_sha,
        "checked_at": now(),
        "checks": checks,
        "verdict": "Package QA PASS: zip is self-consistent and boundary-safe." if status == "PASS" else "Package QA FAIL: fix checks before sharing.",
    }
    write_json(PACKAGE_QA, result)
    audit("package.qa_verified", {"name": pkg.get("name"), "status": status, "checks": len(checks)})
    return result


def latest_package() -> dict | None:
    if not PACKAGE_INDEX.exists():
        return None
    data = read_json(PACKAGE_INDEX, {})
    return data or None


def audit_zip_paths(paths: list[str]) -> dict:
    hits = []
    for rel in paths:
        parts = Path(rel).parts
        if rel.startswith("/") or ".." in parts:
            hits.append({"path": rel, "reason": "unsafe_path"})
        for token in PACKAGE_FORBIDDEN_TOKENS:
            if token in rel:
                hits.append({"path": rel, "reason": f"forbidden_token:{token}"})
    return {"status": "PASS" if not hits else "FAIL", "hits": hits, "rules": PACKAGE_FORBIDDEN_TOKENS + ["no_absolute_path", "no_parent_traversal"]}


def build_beta_package() -> dict:
    manifest = generate_package_manifest()
    readiness_status = manifest.get("readiness", {}).get("status")
    if readiness_status != "PASS":
        raise ValueError(f"release readiness is {readiness_status}; package build blocked")
    version = VERSION
    package_name = f"harness-local-v{version}-beta.zip"
    package_root = f"harness-local-v{version}-beta"
    zip_path = PACKAGES / package_name
    with tempfile.TemporaryDirectory(prefix="harness-package-staging-") as tmp:
        staging = Path(tmp) / package_root
        staging.mkdir(parents=True, exist_ok=True)
        copied = []
        for item in manifest.get("files", []):
            rel = item.get("path", "")
            if not rel:
                continue
            if audit_zip_paths([rel]).get("status") != "PASS":
                raise ValueError(f"unsafe package path blocked: {rel}")
            src = ROOT / rel
            if not src.exists() or not src.is_file():
                raise ValueError(f"manifest file missing: {rel}")
            dst = staging / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            copied.append(rel)
        # Include the generated commercial-safe manifest in the package.
        manifest_dst = staging / "RELEASE-MANIFEST.json"
        shutil.copy2(PACKAGE_MANIFEST, manifest_dst)
        copied.append("RELEASE-MANIFEST.json")
        zip_entries = [f"{package_root}/{rel}" for rel in copied]
        audit_result = audit_zip_paths(zip_entries)
        if audit_result.get("status") != "PASS":
            raise ValueError(f"zip audit failed: {audit_result.get('hits')}")
        if zip_path.exists():
            zip_path.unlink()
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for rel in copied:
                src = staging / rel
                zf.write(src, f"{package_root}/{rel}")
    size = zip_path.stat().st_size
    sha = _sha256_file(zip_path)
    result = {
        "status": "PASS",
        "name": package_name,
        "path": str(zip_path),
        "download_url": f"/packages/{package_name}",
        "size": size,
        "sha256": sha,
        "file_count": len(copied),
        "version": version,
        "built_at": now(),
        "audit": audit_zip_paths([x for x in zip_entries]),
    }
    write_json(PACKAGE_INDEX, result)
    audit("package.built", {"name": package_name, "size": size, "sha256": sha, "file_count": len(copied)})
    return result

def release_readiness() -> dict:
    checks = []
    # package root boundary
    boundary = scan_package_boundary(str(ROOT))
    checks.append({"id": "package_boundary", "status": "PASS" if boundary.get("status") == "PASS" else "FAIL", "summary": f"forbidden hits={len(boundary.get('hits', []))}", "details": boundary})
    # product README
    readme = ROOT / "README.md"
    readme_text = readme.read_text(encoding="utf-8") if readme.exists() else ""
    forbidden_terms = ["CEO 私有", "FOS", "workspace-main", "CREDENTIALS", "openclaw.json"]
    term_hits = [t for t in forbidden_terms if t in readme_text]
    checks.append({"id": "beta_readme", "status": "PASS" if readme.exists() and not term_hits else "WARN", "summary": "README exists and avoids internal terms" if not term_hits else f"README term hits: {term_hits}", "details": {"exists": readme.exists(), "term_hits": term_hits}})
    # plugins disabled by default
    plugins = read_plugins()
    enabled_plugins = [p.get("id") for p in plugins if p.get("enabled")]
    checks.append({"id": "plugins_disabled", "status": "PASS" if not enabled_plugins else "WARN", "summary": f"enabled_plugins={len(enabled_plugins)}", "details": {"enabled_plugins": enabled_plugins, "plugins": plugins}})
    # server bind expectation (documentary check; actual launcher controls host)
    checks.append({"id": "local_first", "status": "PASS", "summary": "Harness Local is designed for 127.0.0.1 local-first operation", "details": {"cloud_upload_default": False, "destructive_runner_default": False}})
    # docs exist
    required_docs = ["docs/HARNESS-API-CONTRACT-V0.7-20260612.md", "desktop/tauri-shell-skeleton/SERVICE-LIFECYCLE-CHECKLIST.md", "docs/HARNESS-LOCAL-3MIN-DEMO-SCRIPT-20260612.md"]
    missing = [d for d in required_docs if not (ROOT / d).exists()]
    checks.append({"id": "docs", "status": "PASS" if not missing else "WARN", "summary": "required docs present" if not missing else f"missing={missing}", "details": {"missing": missing}})
    order = {"FAIL": 2, "WARN": 1, "PASS": 0}
    status = max((c["status"] for c in checks), key=lambda x: order[x])
    return {"status": status, "checked_at": now(), "checks": checks, "verdict": "Ready for local beta packaging" if status == "PASS" else "Resolve WARN/FAIL before packaging"}


class Handler(BaseHTTPRequestHandler):
    server_version = f"HarnessLocal/{VERSION}"

    def _send(self, status: int, data, content_type="application/json"):
        body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        n = int(self.headers.get("content-length", "0") or 0)
        if n <= 0:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/health":
            return self._send(200, {"status": "ok", "product": "Harness Local", "version": VERSION, "ts": now()})
        if path == "/api/workspaces":
            rows = read_json(WORKSPACES, [])
            if parsed.query != "include_archived=1":
                rows = [r for r in rows if not r.get("archived")]
            return self._send(200, rows)
        if path.startswith("/api/workspaces/") and path.endswith("/context"):
            workspace_id = path.split("/")[3]
            ws = get_workspace(workspace_id)
            if ws is None:
                return self._send(404, {"error": "workspace_not_found"})
            scan = scan_workspace(ws["path"])
            ws = update_workspace(workspace_id, scan=scan)
            audit("workspace.context_refreshed", {"id": workspace_id})
            return self._send(200, {"workspace": ws, "scan": scan})
        if path.startswith("/api/workspaces/") and path.endswith("/boundary"):
            workspace_id = path.split("/")[3]
            ws = get_workspace(workspace_id)
            if ws is None:
                return self._send(404, {"error": "workspace_not_found"})
            result = scan_package_boundary(ws["path"])
            audit("workspace.boundary_scan", {"id": workspace_id, "status": result["status"], "hits": len(result["hits"])})
            return self._send(200, result)
        if path == "/api/audit/summary":
            return self._send(200, latest_safe_audit_summary())

        if path == "/api/plugins":
            return self._send(200, read_plugins())
        if path == "/api/release/boundary":
            return self._send(200, release_boundary_summary())

        if path == "/api/release/readiness":
            return self._send(200, release_readiness())
        if path == "/api/release/summary":
            return self._send(200, release_summary())
        if path == "/api/release/candidate":
            return self._send(200, get_release_candidate() or {"status": "NOT_LOCKED"})
        if path == "/api/doctor":
            return self._send(200, doctor_check())
        if path == "/api/demo":
            return self._send(200, demo_status())
        if path == "/api/demo/clean":
            return self._send(200, clean_demo())
        if path == "/api/evidence/export":
            return self._send(200, latest_evidence_pack() or {"status": "NOT_EXPORTED"})
        if path == "/api/first-run":
            return self._send(200, {"status": "READY", "version": VERSION, "command": "./harness first-run", "steps": ["clean-demo", "demo", "package-build", "package-verify", "candidate-lock", "doctor", "export-evidence", "trial-note", "print-checklist", "trial-bundle"]})
        if path == "/api/trial-note":
            return self._send(200, latest_trial_note() or {"status": "NOT_GENERATED", "command": "./harness trial-note"})
        if path == "/api/print-checklist":
            return self._send(200, latest_print_checklist() or {"status": "NOT_GENERATED", "command": "./harness print-checklist"})
        if path == "/api/feedback":
            return self._send(200, {"status": "PASS", "version": VERSION, "items": feedback_items(), "count": len(feedback_items()), "local_only": True})
        if path == "/api/feedback/summary":
            return self._send(200, latest_feedback_summary() or {"status": "NOT_EXPORTED", "command": "./harness feedback-export", "feedback_count": len(feedback_items())})
        if path == "/api/trial-bundle":
            return self._send(200, latest_trial_bundle() or {"status": "NOT_GENERATED", "command": "./harness trial-bundle"})
        if path == "/release-candidate.json":
            candidate = get_release_candidate()
            if not candidate:
                return self._send(404, {"error": "release_candidate_not_locked"})
            return self._send(200, json.dumps(candidate, ensure_ascii=False, indent=2).encode("utf-8"), "application/json; charset=utf-8")

        if path == "/api/package/manifest":
            return self._send(200, get_package_manifest())
        if path == "/api/package/latest":
            return self._send(200, latest_package() or {})
        if path == "/api/package/qa":
            return self._send(200, latest_package_qa() or {})
        if path.startswith("/packages/"):
            name = Path(path).name
            if name != path.split("/")[-1] or not name.endswith(".zip") or ".." in name:
                return self._send(404, {"error": "not_found"})
            f = PACKAGES / name
            if not f.exists() or not f.is_file():
                return self._send(404, {"error": "not_found"})
            return self._send(200, f.read_bytes(), "application/zip")

        if path.startswith("/evidence/"):
            rel = path[len("/evidence/"):].lstrip("/")
            target = (EVIDENCE / rel).resolve()
            root = EVIDENCE.resolve()
            if not str(target).startswith(str(root)) or not target.exists() or not target.is_file():
                return self._send(404, {"error": "evidence_file_not_found"})
            if target.suffix == ".json":
                return self._send(200, read_json(target, {}))
            if target.suffix in {".md", ".txt", ""}:
                return self._send(200, target.read_bytes(), "text/plain; charset=utf-8")
            if target.suffix == ".html":
                return self._send(200, target.read_bytes(), "text/html; charset=utf-8")
            return self._send(403, {"error": "unsupported_evidence_file"})

        if path == "/api/tasks":
            return self._send(200, read_jsonl(TASKS))
        if path == "/api/runs":
            return self._send(200, read_jsonl(RUNS))
        if path == "/api/audit":
            return self._send(200, read_jsonl(AUDIT)[-200:])
        if path == "/api/settings":
            return self._send(200, get_settings())
        if path == "/api/reports":
            return self._send(200, list_reports())
        if path.startswith("/docs/"):
            name = Path(path).name
            allow = {"HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md", "HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.23-20260612.md", "HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.22-20260612.md", "HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.21-20260612.md", "HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.20-20260612.md"}
            if name not in allow:
                return self._send(404, {"error": "not_found"})
            f = ROOT / "docs" / name
            if not f.exists():
                return self._send(404, {"error": "not_found"})
            return self._send(200, f.read_bytes(), "text/markdown; charset=utf-8")
        if path.startswith("/reports/"):
            name = Path(path).name
            if not name.startswith("report_") or not name.endswith(".md"):
                return self._send(404, {"error": "not_found"})
            f = REPORTS / name
            if not f.exists():
                return self._send(404, {"error": "not_found"})
            return self._send(200, f.read_bytes(), "text/markdown; charset=utf-8")
        if path in {"/", "/index.html"}:
            f = STATIC / "index.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if path == "/release":
            f = STATIC / "release.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if path == "/first-run":
            f = STATIC / "first-run.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if path == "/feedback":
            f = STATIC / "feedback.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if path == "/package-qa":
            f = STATIC / "package-qa.html"
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        f = STATIC / path.lstrip("/")
        if f.exists() and f.is_file():
            ctype = "text/plain"
            if f.suffix == ".css":
                ctype = "text/css"
            if f.suffix == ".js":
                ctype = "application/javascript"
            return self._send(200, f.read_bytes(), ctype)
        return self._send(404, {"error": "not_found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            body = self._read_body()
            if path == "/api/workspaces":
                scan = scan_workspace(body.get("path", ""))
                workspaces = read_json(WORKSPACES, [])
                for existing in workspaces:
                    if normalize_path(existing.get("path", "")) == scan["path"]:
                        existing["scan"] = scan
                        existing["updated_at"] = now()
                        write_json(WORKSPACES, workspaces)
                        audit("workspace.deduped", {"id": existing["id"], "path": existing["path"]})
                        return self._send(200, existing)
                ws = {
                    "id": "ws_" + uuid.uuid4().hex[:10],
                    "name": body.get("name") or Path(scan["path"]).name,
                    "path": scan["path"],
                    "scan": scan,
                    "created_at": now(),
                }
                workspaces.append(ws)
                write_json(WORKSPACES, workspaces)
                audit("workspace.created", {"id": ws["id"], "path": ws["path"]})
                return self._send(201, ws)
            if path == "/api/tasks":
                workspace_id = body.get("workspace_id")
                workspace = get_workspace(workspace_id) if workspace_id else None
                if workspace_id and workspace is None:
                    raise ValueError("workspace not found")
                task = {
                    "id": "task_" + uuid.uuid4().hex[:10],
                    "workspace_id": workspace_id,
                    "goal": body.get("goal", ""),
                    "status": "TODO",
                    "steps": plan_steps(body.get("goal", ""), workspace),
                    "created_at": now(),
                }
                append_jsonl(TASKS, task)
                audit("task.created", {"id": task["id"], "goal": task["goal"], "steps": len(task["steps"])})
                return self._send(201, task)
            if path == "/api/package/manifest":
                result = generate_package_manifest()
                audit("package.manifest_generated", {"file_count": result.get("file_count"), "total_size": result.get("total_size"), "status": result.get("readiness", {}).get("status")})
                return self._send(200, get_package_manifest())
            if path == "/api/package/build":
                result = build_beta_package()
                return self._send(200, result)
            if path == "/api/package/verify":
                result = verify_latest_package()
                return self._send(200, result)
            if path == "/api/release/candidate/lock":
                result = release_candidate_lock()
                return self._send(200, result)
            if path == "/api/doctor":
                result = doctor_check()
                return self._send(200, result)
            if path == "/api/demo":
                result = run_demo()
                return self._send(200, result)
            if path == "/api/demo/clean":
                result = clean_demo()
                return self._send(200, result)
            if path == "/api/evidence/export":
                result = export_evidence_pack()
                return self._send(200, result)
            if path == "/api/first-run":
                result = first_run()
                return self._send(200, result)
            if path == "/api/trial-note":
                result = generate_trial_note()
                return self._send(200, result)
            if path == "/api/print-checklist":
                result = generate_print_checklist()
                return self._send(200, result)
            if path == "/api/feedback":
                result = submit_feedback(body)
                return self._send(200, result)
            if path == "/api/feedback/export":
                result = export_feedback_summary()
                return self._send(200, result)
            if path == "/api/trial-bundle":
                result = generate_trial_bundle()
                return self._send(200, result)

            if path == "/api/workspaces/cleanup":
                result = cleanup_duplicate_workspaces()
                audit("workspace.cleanup", result)
                return self._send(200, result)

            if path.startswith("/api/workspaces/") and path.endswith("/archive"):
                workspace_id = path.split("/")[3]
                ws = archive_workspace(workspace_id)
                audit("workspace.archived", {"id": workspace_id})
                return self._send(200, ws)

            if path.startswith("/api/tasks/") and path.endswith("/audit"):
                task_id = path.split("/")[3]
                task = get_task(task_id)
                if task is None:
                    raise ValueError("task not found")
                workspace = get_workspace(task.get("workspace_id"))
                if workspace is None:
                    raise ValueError("workspace not found")
                update_task(task_id, status="RUNNING")
                report = make_safe_audit_report(workspace, task)
                run = {"id": "run_" + uuid.uuid4().hex[:10], "task_id": task_id, "workspace_id": workspace["id"], "runner": "safe_audit", "status": "DONE" if report["boundary"].get("status") == "PASS" else "BLOCKED", "stdout": report["summary"] + "\n" + report["url"], "stderr": "", "returncode": 0 if report["boundary"].get("status") == "PASS" else 2, "created_at": now(), "completed_at": now(), "report_id": report["id"]}
                append_jsonl(RUNS, run)
                update_task(task_id, status=run["status"], last_run_id=run["id"], last_report_id=report["id"])
                audit("task.safe_audit", {"task_id": task_id, "run_id": run["id"], "report_id": report["id"], "status": run["status"]})
                return self._send(201, {"run": run, "report": report})

            if path.startswith("/api/tasks/") and path.endswith("/plan"):
                task_id = path.split("/")[3]
                task = get_task(task_id)
                if task is None:
                    raise ValueError("task not found")
                workspace = get_workspace(task.get("workspace_id"))
                steps = plan_steps(task.get("goal", ""), workspace)
                updated = update_task(task_id, steps=steps)
                audit("task.planned", {"task_id": task_id, "steps": len(steps)})
                return self._send(200, updated)
            if path.startswith("/api/tasks/") and path.endswith("/diff"):
                task_id = path.split("/")[3]
                task = get_task(task_id)
                if task is None:
                    raise ValueError("task not found")
                workspace = get_workspace(task.get("workspace_id"))
                if workspace is None:
                    raise ValueError("workspace not found")
                update_task(task_id, status="RUNNING")
                started = now()
                result = run_git_diff_summary(workspace["path"])
                run = {"id": "run_" + uuid.uuid4().hex[:10], "task_id": task_id, "workspace_id": workspace["id"], "runner": "git_diff_summary", "status": result["status"], "stdout": result["stdout"], "stderr": result["stderr"], "returncode": result["returncode"], "created_at": started, "completed_at": now()}
                append_jsonl(RUNS, run)
                update_task(task_id, status=run["status"], last_run_id=run["id"])
                audit("task.diff", {"task_id": task_id, "run_id": run["id"], "runner": run["runner"], "status": run["status"]})
                return self._send(201, run)
            if path.startswith("/api/tasks/") and path.endswith("/run"):
                task_id = path.split("/")[3]
                task = get_task(task_id)
                if task is None:
                    raise ValueError("task not found")
                workspace = get_workspace(task.get("workspace_id"))
                if workspace is None:
                    raise ValueError("workspace not found")
                update_task(task_id, status="RUNNING")
                started = now()
                result = run_git_status(workspace["path"])
                run = {
                    "id": "run_" + uuid.uuid4().hex[:10],
                    "task_id": task_id,
                    "workspace_id": workspace["id"],
                    "runner": "git_status",
                    "status": result["status"],
                    "stdout": result["stdout"],
                    "stderr": result["stderr"],
                    "returncode": result["returncode"],
                    "created_at": started,
                    "completed_at": now(),
                }
                append_jsonl(RUNS, run)
                update_task(task_id, status=run["status"], last_run_id=run["id"])
                audit("task.run", {"task_id": task_id, "run_id": run["id"], "runner": run["runner"], "status": run["status"]})
                return self._send(201, run)
            if path == "/api/reports":
                report = make_markdown_report()
                audit("report.generated", {"id": report["id"], "path": report["path"]})
                return self._send(201, report)
            if path == "/api/settings":
                return self._send(200, save_settings(body))
            return self._send(404, {"error": "not_found"})
        except Exception as e:
            return self._send(400, {"error": str(e)})

    def log_message(self, fmt, *args):
        print(f"[{now()}] {self.address_string()} {fmt % args}")


def main():
    host = os.environ.get("HARNESS_HOST", "127.0.0.1")
    port = int(os.environ.get("HARNESS_PORT", "8788"))
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"Harness Local v{VERSION} listening on http://{host}:{port}")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
