const $ = (id) => document.getElementById(id);
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function showBanner(type, msg){ const b=$('banner'); if(!b) return; b.className=`banner ${type||'info'}`; b.textContent=msg; }
function clearBanner(){ const b=$('banner'); if(b){ b.className='banner hidden'; b.textContent=''; } }
async function api(path, opts = {}) {
  const r = await fetch(path, { headers: { 'content-type': 'application/json' }, ...opts });
  let data = null;
  try { data = await r.json(); } catch(e) { data = { error: `Invalid response from ${path}` }; }
  if (!r.ok || data?.error) throw new Error(data?.error || `${r.status} ${r.statusText}`);
  return data;
}
function badge(status){ const s=String(status||'UNKNOWN'); const cls=s==='PASS'||s==='DONE'||s==='ok'?'success':(s==='FAIL'||s==='ERROR'?'danger':'neutral'); return `<span class="badge ${cls}">${esc(s)}</span>`; }
function emptyState(title, body, action='') { return `<div class="empty"><div class="empty-icon">◎</div><b>${esc(title)}</b><p>${esc(body)}</p>${action}</div>`; }
function stepHtml(steps){return (steps||[]).map(st=>`<li><span class="step-dot"></span><div><b>${esc(st.title)}</b><small><code>${esc(st.id)}</code> · ${esc(st.safety)}</small></div></li>`).join('')}

async function refresh() {
  clearBanner();
  try {
    const h = await api('/health');
    $('health').innerHTML = `${badge(h.status)} <span>v${esc(h.version)} · local</span>`;
  } catch (e) {
    $('health').textContent = 'offline';
    showBanner('danger', `Server offline: ${e.message}`);
    return;
  }
  try {
    const [pkg, release, ws, tasks, runs, settings, reports] = await Promise.all([
      api('/api/package/manifest'), api('/api/release/readiness'), api('/api/workspaces'), api('/api/tasks'), api('/api/runs'), api('/api/settings'), api('/api/reports')
    ]);
    $('metricWorkspaces').textContent = ws.length;
    $('metricTasks').textContent = tasks.length;
    $('metricRuns').textContent = runs.length;
    $('metricRelease').textContent = release.status || '—';

    renderPackage(pkg);
    renderRelease(release, pkg.latest_package_qa);
    renderGuide();
    renderWorkspaces(ws);
    renderTasks(tasks);
    renderRuns(runs);
    renderReports(reports);
    $('modelProvider').value = settings.model_provider || '';
    $('localEndpoint').value = settings.local_endpoint || '';
    $('keyMode').textContent = `API key mode: ${settings.key_mode || 'user_provided_not_stored_in_v0'}`;
  } catch(e) {
    showBanner('danger', `Refresh failed: ${e.message}`);
  }
}

function renderPackage(pkg){
  const f=pkg?.files||[];
  const qa=pkg?.latest_package_qa;
  $('package').innerHTML=`<div class="panel-head"><div><p class="eyebrow">Beta packaging</p><h2>Package manifest</h2></div>${badge(pkg?.readiness?.status)}</div>
    <div class="package-stats"><div><span>Version</span><b>v${esc(pkg.version||'?')}</b></div><div><span>Files</span><b>${f.length}</b></div><div><span>Size</span><b>${Math.round((pkg.total_size||0)/1024)}KB</b></div></div>
    <p class="checksum">sha256 <code>${esc((pkg.manifest_sha256||'').slice(0,24))}</code></p>
    <div class="item-actions"><button class="btn" onclick="genManifest()">Regenerate manifest</button><button class="btn primary" onclick="buildPackage()">Build beta zip</button><button class="btn" onclick="verifyPackage()">Verify latest zip</button><a class="btn ghost" href="/package-qa" target="_blank">QA page</a></div>${packageDownloadHtml(pkg.latest_package)}${packageQaHtml(qa)}`;
}

function packageQaHtml(qa){
  if(!qa || !qa.status) return `<div class="empty slim"><b>No QA verification yet</b><p>Run Verify latest zip before sharing a package.</p></div>`;
  return `<div class="download-card qa-card"><div><b>QA ${esc(qa.status)}</b><small>${esc(qa.package||'')} · ${esc(qa.verdict||'')}</small></div>${badge(qa.status)}</div>`;
}

function packageDownloadHtml(pkg){
  if(!pkg || !pkg.name) return `<div class="empty slim"><b>No beta zip yet</b><p>Build a local beta package from the safe manifest whitelist.</p></div>`;
  return `<div class="download-card"><div><b>${esc(pkg.name)}</b><small>${Math.round((pkg.size||0)/1024)}KB · ${esc((pkg.sha256||'').slice(0,20))}</small></div><a class="btn small primary" href="${esc(pkg.download_url)}" download>Download zip</a></div>`;
}

function renderRelease(rel, qa){
  const qaBlock = qa && qa.status ? `<div class="qa-summary ${qa.status==='PASS'?'ok':'bad'}"><div><b>Package QA ${esc(qa.status)}</b><small>${esc(qa.package||'latest package')} · ${esc(qa.verdict||'')}</small></div>${badge(qa.status)}</div>` : `<div class="qa-summary warn"><div><b>Package QA not verified</b><small>Run Verify latest zip before sharing.</small></div>${badge('WARN')}</div>`;
  const checks=(rel.checks||[]).map(c=>`<li><span>${esc(c.id)}</span>${badge(c.status)}<small>${esc(c.summary)}</small></li>`).join('');
  $('releaseCard').innerHTML=`<div class="panel-head"><div><p class="eyebrow">Release gate</p><h2>Readiness</h2></div>${badge(rel.status)}</div>
    <p class="hint">${esc(rel.verdict||'No verdict')}</p>${qaBlock}<ul class="check-list">${checks}</ul>`;
}
function renderGuide(){
  $('guide').innerHTML=`<div class="panel-head"><div><p class="eyebrow">First run</p><h2>Install guide</h2></div><span class="tag neutral">zero cloud</span></div>
    <pre class="terminal">cd harness-commercial\n./harness serve\nopen http://127.0.0.1:8788</pre>
    <p class="hint">完整指南：<code>docs/HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md</code></p>`;
}
function renderWorkspaces(ws){
  $('workspaces').innerHTML = ws.map(w => {
    const entries=(w.scan?.entries||[]).slice(0,8).map(e=>`${e.type==='dir'?'📁':'📄'} ${esc(e.name)}${e.skipped?' (skipped)':''}`).join('<br>');
    const readme=esc((w.scan?.readme_excerpt||'').slice(0,360));
    return `<div class="item workspace-item"><div class="item-main"><b>${esc(w.name)}</b><code>${esc(w.path)}</code><div>${badge(w.scan?.git ? 'git' : 'folder')} <span class="pill">${(w.scan?.entries||[]).length} entries</span></div></div><div class="item-actions"><button class="btn small" onclick="refreshContext('${w.id}')">Refresh</button><button class="btn small" onclick="scanBoundary('${w.id}')">Boundary</button><button class="btn small ghost" onclick="archiveWorkspace('${w.id}')">Archive</button></div><details><summary>Context preview</summary><p>${entries}</p>${readme?`<pre>${readme}</pre>`:''}</details></div>`;
  }).join('') || emptyState('No workspace yet','Add a local project path to start a read-only scan.','<button class="btn small" onclick="document.getElementById(\'wsPath\').focus()">Add workspace</button>');
  $('workspaceSelect').innerHTML = ws.map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join('') || '<option value="">No workspace available</option>';
}
function renderTasks(tasks){
  $('tasks').innerHTML = tasks.slice().reverse().map(t => `<div class="item"><div class="item-main">${badge(t.status)} <b>${esc(t.goal)}</b><code>${esc(t.id)}</code>${t.last_run_id?`<small>last run: ${esc(t.last_run_id)}</small>`:''}</div><div class="item-actions"><button class="btn small" onclick="planTask('${t.id}')">Re-plan</button><button class="btn small" onclick="runTask('${t.id}')">Status</button><button class="btn small" onclick="diffTask('${t.id}')">Diff</button><button class="btn small primary" onclick="auditTask('${t.id}')">Safe audit</button></div><details open><summary>Plan steps</summary><ol class="steps">${stepHtml(t.steps)}</ol></details></div>`).join('') || emptyState('No task yet','Create a task from a workspace to generate a safe execution plan.','<button class="btn small" onclick="document.getElementById(\'taskGoal\').focus()">Create task</button>');
}
function renderRuns(runs){
  $('runs').innerHTML = runs.slice(-20).reverse().map(r => `<div class="item compact">${badge(r.status)} <b>${esc(r.runner)}</b><code>${esc(r.stdout || '(empty stdout)')}</code>${r.stderr ? `<code class="err">${esc(r.stderr)}</code>` : ''}</div>`).join('') || emptyState('No evidence yet','Run git status, diff summary, or safe audit to collect local evidence.');
}
function renderReports(reports){
  const el=$('report'); if(el.dataset.generated) return;
  el.innerHTML = reports.map(r=>`<div class="item compact"><b>${esc(r.name)}</b><code>${esc(r.path)}</code><div class="item-actions"><a class="btn small" href="${esc(r.url)}" target="_blank">Open</a><button class="btn small" onclick="viewReport('${esc(r.url)}')">View inline</button><button class="btn small ghost" onclick="copyText(location.origin + '${esc(r.url)}')">Copy link</button></div></div>`).join('') || emptyState('No reports yet','Run a safe audit or generate a Markdown report.');
}

async function addWorkspace() { try { const path = $('wsPath').value.trim(); if (!path) return showBanner('warn','Input a local workspace path first.'); await api('/api/workspaces', { method: 'POST', body: JSON.stringify({ path }) }); $('wsPath').value=''; showBanner('success','Workspace added.'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function createTask() { try { const workspace_id = $('workspaceSelect').value; const goal = $('taskGoal').value.trim(); if (!workspace_id || !goal) return showBanner('warn','Select workspace and input goal first.'); await api('/api/tasks', { method: 'POST', body: JSON.stringify({ workspace_id, goal }) }); $('taskGoal').value = ''; showBanner('success','Task created.'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function runTask(id) { try { await api(`/api/tasks/${id}/run`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function diffTask(id) { try { await api(`/api/tasks/${id}/diff`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function auditTask(id) { try { const res = await api(`/api/tasks/${id}/audit`, { method: 'POST', body: '{}' }); if (res.report?.url) await viewReport(res.report.url); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function planTask(id) { try { await api(`/api/tasks/${id}/plan`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function refreshContext(id) { try { await api(`/api/workspaces/${id}/context`); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function scanBoundary(id) { try { const res = await api(`/api/workspaces/${id}/boundary`); showBanner(res.status==='PASS'?'success':'danger', `Boundary scan: ${res.status} · hits=${(res.hits||[]).length}`); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function archiveWorkspace(id) { if(!confirm('Archive this workspace? It will not delete files.')) return; try { await api(`/api/workspaces/${id}/archive`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function copyText(text) { try { await navigator.clipboard.writeText(text); showBanner('success','Copied to clipboard.'); } catch(e) { prompt('Copy link', text); } }
async function viewReport(url) { try { const txt = await fetch(url).then(r => r.text()); const el = $('viewer'); el.innerHTML = `<div class="panel-head"><div><p class="eyebrow">Markdown preview</p><h2>Inline report viewer</h2></div></div><pre>${esc(txt)}</pre>`; el.scrollIntoView({behavior:'smooth'}); } catch(e){ showBanner('danger', e.message); } }
async function saveSettings() { try { const body = { model_provider: $('modelProvider').value.trim(), local_endpoint: $('localEndpoint').value.trim() }; await api('/api/settings', { method: 'POST', body: JSON.stringify(body) }); showBanner('success','Settings saved locally.'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function genManifest() { try { await api('/api/package/manifest', { method: 'POST', body: '{}' }); showBanner('success','Package manifest regenerated.'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function buildPackage() { try { showBanner('info','Building beta zip from safe manifest whitelist...'); const res = await api('/api/package/build', { method: 'POST', body: '{}' }); showBanner('success', `Beta zip ready: ${res.name} · ${Math.round((res.size||0)/1024)}KB`); await refresh(); } catch(e){ showBanner('danger', `Package build failed: ${e.message}`); } }
async function verifyPackage() { try { showBanner('info','Verifying latest beta zip...'); const res = await api('/api/package/verify', { method: 'POST', body: '{}' }); showBanner(res.status==='PASS'?'success':'danger', `Package QA ${res.status}: ${res.verdict}`); await refresh(); } catch(e){ showBanner('danger', `Package QA failed: ${e.message}`); } }
async function generateReport() { try { const res = await api('/api/reports', { method: 'POST', body: '{}' }); const el=$('report'); el.dataset.generated='1'; el.innerHTML = `<div class="item"><b>${esc(res.id)}</b><p>${esc(res.summary)}</p><div class="item-actions"><a class="btn small" href="${esc(res.url)}" target="_blank">Open Markdown</a><button class="btn small" onclick="viewReport('${esc(res.url)}')">View inline</button></div><code>${esc(res.path)}</code></div>`; if(res.url) await viewReport(res.url); await refresh(); } catch(e){ showBanner('danger', e.message); } }
refresh();
