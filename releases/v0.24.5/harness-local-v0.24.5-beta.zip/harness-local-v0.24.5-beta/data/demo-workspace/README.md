# Harness Local 3-minute Demo Workspace

This is a generated local-only demo workspace for Harness Local internal beta validation.

## What it proves

- Add a local workspace without cloud upload.
- Create a sample task.
- Run read-only evidence collection.
- Generate a safe audit report.

No credentials, no destructive commands, no external publishing.
