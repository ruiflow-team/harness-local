const $ = (id) => document.getElementById(id);
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function showBanner(type, msg){ const b=$('banner'); if(!b) return; b.className=`banner ${type||'info'}`; b.textContent=msg; }
function clearBanner(){ const b=$('banner'); if(b){ b.className='banner hidden'; b.textContent=''; } }
async function api(path, opts = {}) {
  const r = await fetch(path, { headers: { 'content-type': 'application/json' }, ...opts });
  let data = null;
  try { data = await r.json(); } catch(e) { data = { error: `接口返回异常： ${path}` }; }
  if (!r.ok || data?.error) throw new Error(data?.error || `${r.status} ${r.statusText}`);
  return data;
}
function badge(status){ const s=String(status||'UNKNOWN'); const cls=s==='PASS'||s==='DONE'||s==='ok'?'success':(s==='FAIL'||s==='ERROR'?'danger':'neutral'); return `<span class="badge ${cls}">${esc(s)}</span>`; }
function emptyState(title, body, action='') { return `<div class="empty"><div class="empty-icon">◎</div><b>${esc(title)}</b><p>${esc(body)}</p>${action}</div>`; }
function stepHtml(steps){return (steps||[]).map(st=>`<li><span class="step-dot"></span><div><b>${esc(st.title)}</b><small><code>${esc(st.id)}</code> · ${esc(st.safety)}</small></div></li>`).join('')}

async function refresh() {
  clearBanner();
  try {
    const h = await api('/health');
    $('health').innerHTML = `${badge(h.status)} <span>v${esc(h.version)} · 本地</span>`;
  } catch (e) {
    $('health').textContent = '离线';
    showBanner('danger', `服务离线：${e.message}`);
    return;
  }
  try {
    const [pkg, release, ws, tasks, runs, settings, reports] = await Promise.all([
      api('/api/package/manifest'), api('/api/release/readiness'), api('/api/workspaces'), api('/api/tasks'), api('/api/runs'), api('/api/settings'), api('/api/reports')
    ]);
    $('metricWorkspaces').textContent = ws.length;
    $('metricTasks').textContent = tasks.length;
    $('metricRuns').textContent = runs.length;
    $('metricRelease').textContent = release.status || '—';

    renderPackage(pkg);
    renderRelease(release, pkg.latest_package_qa);
    renderGuide();
    renderWorkspaces(ws);
    renderTasks(tasks);
    renderRuns(runs);
    renderReports(reports);
    $('modelProvider').value = settings.model_provider || '';
    $('localEndpoint').value = settings.local_endpoint || '';
    $('keyMode').textContent = `API Key 模式：${settings.key_mode || '用户提供，v0 不保存'}`;
  } catch(e) {
    showBanner('danger', `刷新失败：${e.message}`);
  }
}

function renderPackage(pkg){
  const f=pkg?.files||[];
  const qa=pkg?.latest_package_qa;
  $('package').innerHTML=`<div class="panel-head"><div><p class="eyebrow">Beta 安装包</p><h2>安装包清单</h2></div>${badge(pkg?.readiness?.status)}</div>
    <div class="package-stats"><div><span>版本</span><b>v${esc(pkg.version||'?')}</b></div><div><span>文件数</span><b>${f.length}</b></div><div><span>大小</span><b>${Math.round((pkg.total_size||0)/1024)}KB</b></div></div>
    <p class="checksum">sha256 <code>${esc((pkg.manifest_sha256||'').slice(0,24))}</code></p>
    <div class="item-actions"><button class="btn" onclick="genManifest()">重新生成清单</button><button class="btn primary" onclick="buildPackage()">构建 Beta zip</button><button class="btn" onclick="verifyPackage()">校验最新 zip</button><a class="btn ghost" href="/package-qa" target="_blank">QA 页面</a></div>${packageDownloadHtml(pkg.latest_package)}${packageQaHtml(qa)}`;
}

function packageQaHtml(qa){
  if(!qa || !qa.status) return `<div class="empty slim"><b>尚未做 QA 校验</b><p>Run 校验最新 zip before sharing a package.</p></div>`;
  return `<div class="download-card qa-card"><div><b>QA ${esc(qa.status)}</b><small>${esc(qa.package||'')} · ${esc(qa.verdict||'')}</small></div>${badge(qa.status)}</div>`;
}

function packageDownloadHtml(pkg){
  if(!pkg || !pkg.name) return `<div class="empty slim"><b>尚未生成 Beta zip</b><p>从安全白名单清单构建本地 Beta 安装包。</p></div>`;
  return `<div class="download-card"><div><b>${esc(pkg.name)}</b><small>${Math.round((pkg.size||0)/1024)}KB · ${esc((pkg.sha256||'').slice(0,20))}</small></div><a class="btn small primary" href="${esc(pkg.download_url)}" download>下载 zip</a></div>`;
}

function renderRelease(rel, qa){
  const qaBlock = qa && qa.status ? `<div class="qa-summary ${qa.status==='PASS'?'ok':'bad'}"><div><b>Package QA ${esc(qa.status)}</b><small>${esc(qa.package||'latest package')} · ${esc(qa.verdict||'')}</small></div>${badge(qa.status)}</div>` : `<div class="qa-summary warn"><div><b>安装包 QA 未校验</b><small>Run 校验最新 zip before sharing.</small></div>${badge('WARN')}</div>`;
  const checks=(rel.checks||[]).map(c=>`<li><span>${esc(c.id)}</span>${badge(c.status)}<small>${esc(c.summary)}</small></li>`).join('');
  $('releaseCard').innerHTML=`<div class="panel-head"><div><p class="eyebrow">发布门禁</p><h2>就绪状态</h2></div>${badge(rel.status)}</div>
    <p class="hint">${esc(rel.verdict||'暂无结论')}</p>${qaBlock}<ul class="check-list">${checks}</ul>`;
}
function renderGuide(){
  $('guide').innerHTML=`<div class="panel-head"><div><p class="eyebrow">首次运行</p><h2>安装指南</h2></div><span class="tag neutral">零云端依赖</span></div>
    <pre class="terminal">cd harness-commercial\n./harness serve\nopen http://127.0.0.1:8788</pre>
    <p class="hint">完整指南：<code>docs/HARNESS-LOCAL-BETA-RELEASE-GUIDE-V0.24-20260612.md</code></p>`;
}
function renderWorkspaces(ws){
  $('workspaces').innerHTML = ws.map(w => {
    const entries=(w.scan?.entries||[]).slice(0,8).map(e=>`${e.type==='dir'?'📁':'📄'} ${esc(e.name)}${e.skipped?' (skipped)':''}`).join('<br>');
    const readme=esc((w.scan?.readme_excerpt||'').slice(0,360));
    return `<div class="item workspace-item"><div class="item-main"><b>${esc(w.name)}</b><code>${esc(w.path)}</code><div>${badge(w.scan?.git ? 'git' : 'folder')} <span class="pill">${(w.scan?.entries||[]).length} entries</span></div></div><div class="item-actions"><button class="btn small" onclick="refreshContext('${w.id}')">刷新</button><button class="btn small" onclick="scan边界检查('${w.id}')">边界检查</button><button class="btn small ghost" onclick="archiveWorkspace('${w.id}')">归档</button></div><details><summary>上下文预览</summary><p>${entries}</p>${readme?`<pre>${readme}</pre>`:''}</details></div>`;
  }).join('') || emptyState('还没有本地项目','添加一个本地项目路径，开始只读扫描。','<button class="btn small" onclick="document.getElementById(\'wsPath\').focus()">添加项目</button>');
  $('workspaceSelect').innerHTML = ws.map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join('') || '<option value="">没有可用项目</option>';
}
function renderTasks(tasks){
  $('tasks').innerHTML = tasks.slice().reverse().map(t => `<div class="item"><div class="item-main">${badge(t.status)} <b>${esc(t.goal)}</b><code>${esc(t.id)}</code>${t.last_run_id?`<small>last run: ${esc(t.last_run_id)}</small>`:''}</div><div class="item-actions"><button class="btn small" onclick="planTask('${t.id}')">重新规划</button><button class="btn small" onclick="runTask('${t.id}')">状态</button><button class="btn small" onclick="diffTask('${t.id}')">差异</button><button class="btn small primary" onclick="auditTask('${t.id}')">安全审计</button></div><details open><summary>规划步骤</summary><ol class="steps">${stepHtml(t.steps)}</ol></details></div>`).join('') || emptyState('还没有任务','从本地项目创建任务，生成安全执行计划。','<button class="btn small" onclick="document.getElementById(\'taskGoal\').focus()">创建任务</button>');
}
function renderRuns(runs){
  $('runs').innerHTML = runs.slice(-20).reverse().map(r => `<div class="item compact">${badge(r.status)} <b>${esc(r.runner)}</b><code>${esc(r.stdout || '(empty stdout)')}</code>${r.stderr ? `<code class="err">${esc(r.stderr)}</code>` : ''}</div>`).join('') || emptyState('还没有证据','运行 git status、diff 摘要或 safe audit 来收集本地证据。');
}
function renderReports(reports){
  const el=$('report'); if(el.dataset.generated) return;
  el.innerHTML = reports.map(r=>`<div class="item compact"><b>${esc(r.name)}</b><code>${esc(r.path)}</code><div class="item-actions"><a class="btn small" href="${esc(r.url)}" target="_blank">打开</a><button class="btn small" onclick="viewReport('${esc(r.url)}')">内嵌查看</button><button class="btn small ghost" onclick="copyText(location.origin + '${esc(r.url)}')">复制链接</button></div></div>`).join('') || emptyState('还没有报告','运行 safe audit 或生成 Markdown 报告。');
}

async function addWorkspace() { try { const path = $('wsPath').value.trim(); if (!path) return showBanner('warn','请先输入本地项目路径。'); await api('/api/workspaces', { method: 'POST', body: JSON.stringify({ path }) }); $('wsPath').value=''; showBanner('success','项目已添加。'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function createTask() { try { const workspace_id = $('workspaceSelect').value; const goal = $('taskGoal').value.trim(); if (!workspace_id || !goal) return showBanner('warn','请先选择项目并输入目标。'); await api('/api/tasks', { method: 'POST', body: JSON.stringify({ workspace_id, goal }) }); $('taskGoal').value = ''; showBanner('success','任务已创建。'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function runTask(id) { try { await api(`/api/tasks/${id}/run`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function diffTask(id) { try { await api(`/api/tasks/${id}/diff`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function auditTask(id) { try { const res = await api(`/api/tasks/${id}/audit`, { method: 'POST', body: '{}' }); if (res.report?.url) await viewReport(res.report.url); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function planTask(id) { try { await api(`/api/tasks/${id}/plan`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function refreshContext(id) { try { await api(`/api/workspaces/${id}/context`); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function scan边界检查(id) { try { const res = await api(`/api/workspaces/${id}/boundary`); showBanner(res.status==='PASS'?'success':'danger', `边界检查 scan: ${res.status} · hits=${(res.hits||[]).length}`); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function archiveWorkspace(id) { if(!confirm('归档这个项目？不会删除本地文件。')) return; try { await api(`/api/workspaces/${id}/archive`, { method: 'POST', body: '{}' }); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function copyText(text) { try { await navigator.clipboard.writeText(text); showBanner('success','已复制到剪贴板。'); } catch(e) { prompt('复制链接', text); } }
async function viewReport(url) { try { const txt = await fetch(url).then(r => r.text()); const el = $('viewer'); el.innerHTML = `<div class="panel-head"><div><p class="eyebrow">Markdown preview</p><h2>Inline report viewer</h2></div></div><pre>${esc(txt)}</pre>`; el.scrollIntoView({behavior:'smooth'}); } catch(e){ showBanner('danger', e.message); } }
async function saveSettings() { try { const body = { model_provider: $('modelProvider').value.trim(), local_endpoint: $('localEndpoint').value.trim() }; await api('/api/settings', { method: 'POST', body: JSON.stringify(body) }); showBanner('success','设置已保存到本机。'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function genManifest() { try { await api('/api/package/manifest', { method: 'POST', body: '{}' }); showBanner('success','安装包清单 regenerated.'); await refresh(); } catch(e){ showBanner('danger', e.message); } }
async function buildPackage() { try { showBanner('info','正在从安全白名单构建 Beta zip...'); const res = await api('/api/package/build', { method: 'POST', body: '{}' }); showBanner('success', `Beta zip 已生成： ${res.name} · ${Math.round((res.size||0)/1024)}KB`); await refresh(); } catch(e){ showBanner('danger', `安装包构建失败： ${e.message}`); } }
async function verifyPackage() { try { showBanner('info','正在校验最新 Beta zip...'); const res = await api('/api/package/verify', { method: 'POST', body: '{}' }); showBanner(res.status==='PASS'?'success':'danger', `Package QA ${res.status}: ${res.verdict}`); await refresh(); } catch(e){ showBanner('danger', `安装包 QA 失败： ${e.message}`); } }
async function generateReport() { try { const res = await api('/api/reports', { method: 'POST', body: '{}' }); const el=$('report'); el.dataset.generated='1'; el.innerHTML = `<div class="item"><b>${esc(res.id)}</b><p>${esc(res.summary)}</p><div class="item-actions"><a class="btn small" href="${esc(res.url)}" target="_blank">打开 Markdown</a><button class="btn small" onclick="viewReport('${esc(res.url)}')">内嵌查看</button></div><code>${esc(res.path)}</code></div>`; if(res.url) await viewReport(res.url); await refresh(); } catch(e){ showBanner('danger', e.message); } }
refresh();
